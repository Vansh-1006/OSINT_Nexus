# OSINT Intelligence Framework v2.0

**Username · Email · Domain** open-source intelligence tool for Kali Linux and Debian.
Discovers public digital footprint across 60+ platforms, APIs, and data sources —
including **technology stack detection with version numbers** for any website.

---

## One-Command Install

```bash
git clone <repo>
cd osint_framework
chmod +x setup.sh && ./setup.sh
```

Requires Python 3.10+. On Kali/Debian:
```bash
sudo apt install python3 python3-pip python3-venv
```

---

## Usage

```bash
# Username investigation
./osint-tool johndoe

# Email investigation
./osint-tool john@example.com

# Domain / website investigation (NEW in v2)
./osint-tool example.com

# Save HTML report
./osint-tool example.com --html

# Save all formats: HTML + JSON + CSV + Markdown
./osint-tool example.com --all-formats

# Deep investigation (3 pivot hops)
./osint-tool johndoe --deep --html

# Custom output directory
./osint-tool johndoe --all-formats --output ~/reports/

# View past investigations
./osint-tool history
./osint-tool show <report-id>
./osint-tool export <report-id> --format html

# List all 16 providers
./osint-tool providers
```

---

## What It Discovers

### Username Target
| Provider | What Found |
|----------|-----------|
| `username_platforms` | Profiles across 60+ platforms (GitHub, Reddit, Twitch, DeviantArt, Keybase…) |
| `github` | Repos, real name, email, organisation, website, avatar |
| `reddit` | Profile, karma, post history, active subreddits |
| `hackernews` | Profile, karma, submissions, bio URLs |
| `duckduckgo` | Indexed web mentions |
| `wayback_machine` | Historical profile snapshots |

### Email Target
| Provider | What Found |
|----------|-----------|
| `email_intel` | Username pivots, name inference, domain pivot, Gravatar avatar |
| `hibp` | Public breach indicators *(paid API key)* |
| `github` | GitHub user search by email |
| `dns` | Domain MX/SPF/DMARC records |
| `rdap` | Domain registration info |
| `duckduckgo` | Indexed mentions |

### Domain Target *(v2 — new)*
| Provider | What Found |
|----------|-----------|
| `web_fingerprint` | **CMS, frameworks, servers, libraries, CDNs, analytics — with versions** |
| `web_content` | Emails, phones, social links, meta description, page title, author |
| `ip_intel` | IP addresses, geolocation, ASN, ISP, hosting provider |
| `subdomain_enum` | Passive subdomain discovery (crt.sh + HackerTarget) |
| `dns` | A, AAAA, MX, NS, TXT, SPF, DMARC, SOA records |
| `rdap` | Registrar, registration date, expiry, nameservers, status |
| `crt_sh` | Certificate Transparency — all TLS certs issued |
| `urlscan` | Web scan: tech stack via Wappalyzer, IPs, links *(free key)* |
| `wayback_machine` | Historical snapshots |
| `duckduckgo` | Indexed content |

---

## Technology Fingerprinting (v2)

Detects **100+ technologies** with version numbers from:

- **HTTP headers** — `Server: nginx/1.21.6`, `X-Powered-By: PHP/8.1.2`, `X-AspNet-Version`
- **HTML meta generator** — `<meta name="generator" content="WordPress 6.4.2">`
- **JavaScript patterns** — `ng-version="17.0.1"`, `__NEXT_DATA__`, `___gatsby`
- **Cookie names** — `laravel_session`, `PHPSESSID`, `cf_clearance`, `__cflb`
- **Path probing** — `/wp-login.php`, `/wp-json/wp/v2/` with body validation

| Category | Technologies |
|----------|-------------|
| CMS | WordPress, Drupal, Joomla, Magento, Shopify, Wix, Squarespace, Ghost, Webflow, PrestaShop, TYPO3 |
| Framework | React, Next.js, Vue.js, Nuxt.js, Angular, Svelte, Gatsby, Astro, Django, Laravel, Rails, ASP.NET, Express, Flask, Spring, FastAPI |
| Server | Apache, Nginx, IIS, LiteSpeed, Caddy, OpenResty, Gunicorn |
| Language | PHP (with version), Python, Ruby, Node.js |
| Library | jQuery (version), Bootstrap (version), Tailwind CSS, Lodash |
| CDN | Cloudflare, AWS CloudFront, Fastly, Akamai |
| Hosting | Vercel, Netlify, GitHub Pages |
| Analytics | Google Analytics, GTM, Matomo, Hotjar, Facebook Pixel, HubSpot |
| Security | Cloudflare WAF, reCAPTCHA, hCaptcha |
| Ecommerce | WooCommerce, Stripe, PayPal |
| Support | Intercom, Zendesk, Crisp |

---

## Optional API Keys (Better Results)

| Key | Benefit | Get It |
|-----|---------|--------|
| `GITHUB_TOKEN` | 60 → 5,000 API req/hr (free) | github.com/settings/tokens |
| `HIBP_API_KEY` | Breach data for emails (~$3.50/mo) | haveibeenpwned.com/API/Key |
| `URLSCAN_API_KEY` | Enhanced web scans with Wappalyzer data (free tier) | urlscan.io/user/signup |

```bash
# Add to ~/.bashrc for persistence
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
export HIBP_API_KEY=your_key
export URLSCAN_API_KEY=your_key
```

---

## Confidence Levels

| Level | Meaning |
|-------|---------|
| `CONFIRMED` | Verified by authoritative source (DNS response, API result, HTTP header) |
| `HIGH` | Strong evidence, directly observed (profile page exists, meta generator tag) |
| `MEDIUM` | Multiple corroborating signals (HTML pattern + cookie match) |
| `LOW` | Single weak signal, needs verification |

---

## Output Formats

```bash
./osint-tool example.com --html      # Dark-theme HTML with entity graph + tech stack section
./osint-tool example.com --json      # Full structured JSON for automation
./osint-tool example.com --csv       # Spreadsheet-ready CSV
./osint-tool example.com --markdown  # Markdown for documentation
./osint-tool example.com --all-formats  # All four at once
```

---

## Configuration

```bash
mkdir -p ~/.osint && cp config/default_config.yaml ~/.osint/config.yaml
nano ~/.osint/config.yaml
```

Key settings:
```yaml
investigation:
  max_depth: 2       # 1=quick, 2=default, 3=deep
  timeout: 12        # seconds per request
  concurrent_limit: 20

providers:
  web_fingerprint:
    enabled: true    # disable any provider
  hibp:
    hibp_api_key: "" # or use env var
```

---

## Architecture

```
Input (username / email / domain)
         │
         ▼
   Type Detection & Normalisation
         │
   ┌─────▼──────────────────────────────────────────┐
   │           16 Providers (concurrent)             │
   │  email_intel · username_platforms · github      │
   │  reddit · hackernews · web_fingerprint          │
   │  web_content · ip_intel · subdomain_enum        │
   │  dns · rdap · crt_sh · wayback · duckduckgo     │
   │  urlscan · hibp                                 │
   └─────┬──────────────────────────────────────────┘
         │
   Finding Extraction → Pivot Generation
         │
   New targets discovered → re-investigate (max_depth hops)
         │
   Deduplication + Confidence Scoring
         │
   Report: Terminal · HTML · JSON · CSV · Markdown
         │
   SQLite database (history / show / export)
```

---

## Project Structure

```
osint_framework/
├── setup.sh                          ← Run once to install
├── config/default_config.yaml        ← All settings
├── data/platforms.yaml               ← 60+ platform definitions
└── src/osint/
    ├── cli.py                        ← CLI: investigate/history/show/export
    ├── engine.py                     ← BFS pivot engine
    ├── models.py                     ← Pydantic data models
    ├── config.py / utils.py          ← Config + helpers
    ├── database.py                   ← SQLite persistence
    ├── tech_signatures.py            ← 100+ tech fingerprint signatures
    ├── providers/
    │   ├── domain/
    │   │   ├── web_fingerprint.py    ← ★ Technology stack detection
    │   │   ├── web_content.py        ← Emails, phones, social links
    │   │   ├── ip_intel.py           ← IP geolocation + ASN
    │   │   ├── subdomain_enum.py     ← Passive subdomain discovery
    │   │   ├── dns_provider.py       ← DNS record enumeration
    │   │   └── rdap_provider.py      ← WHOIS/RDAP registration
    │   ├── social/
    │   │   ├── reddit_provider.py    ← Reddit posts + subreddit activity
    │   │   └── hackernews.py         ← HN karma, posts, bio URLs
    │   ├── developer/github.py       ← GitHub full profile
    │   ├── usernames/platform_checker.py ← 60+ platform probing
    │   ├── email/gravatar.py         ← Gravatar + email decomposition
    │   ├── breach/hibp.py            ← HaveIBeenPwned
    │   ├── certificates/crtsh.py     ← Certificate Transparency
    │   ├── archives/wayback.py       ← Wayback Machine CDX
    │   └── search/
    │       ├── duckduckgo.py         ← Web search
    │       └── urlscan.py            ← URLScan.io web analysis
    └── reporters/
        ├── terminal.py               ← Rich terminal output
        ├── html_reporter.py          ← Dark-theme HTML + Mermaid graph
        ├── json_reporter.py
        ├── csv_reporter.py
        └── markdown_reporter.py
```

---

## Legal

For authorised OSINT research, security investigations, and defensive purposes only.
Only queries publicly accessible information. Never bypasses authentication or access controls.
Comply with applicable laws (GDPR, CFAA, Computer Misuse Act) and platform terms of service.
