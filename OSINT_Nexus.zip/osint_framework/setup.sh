#!/usr/bin/env bash
set -e
BLUE='\033[1;34m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; RED='\033[1;31m'; NC='\033[0m'
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$SCRIPT_DIR/.venv"

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║     OSINT Intelligence Framework  v2.0               ║"
echo "║              One-Command Setup                       ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${BLUE}[1/5] Checking Python 3.10+...${NC}"
if ! command -v python3 &>/dev/null; then
  echo -e "${RED}Python3 not found. Run: sudo apt install python3 python3-pip python3-venv${NC}"; exit 1
fi
PYVER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PYMAJ=$(python3 -c "import sys; print(sys.version_info.major)")
PYMIN=$(python3 -c "import sys; print(sys.version_info.minor)")
if [ "$PYMAJ" -lt 3 ] || { [ "$PYMAJ" -eq 3 ] && [ "$PYMIN" -lt 10 ]; }; then
  echo -e "${RED}Python 3.10+ required. You have $PYVER${NC}"; exit 1
fi
echo -e "  ${GREEN}✓ Python $PYVER${NC}"

echo -e "${BLUE}[2/5] Creating virtual environment...${NC}"
if [ ! -d "$VENV" ]; then
  python3 -m venv "$VENV"
  echo -e "  ${GREEN}✓ Created .venv/${NC}"
else
  echo -e "  ${YELLOW}→ .venv/ already exists${NC}"
fi

echo -e "${BLUE}[3/5] Installing dependencies (1-2 minutes first time)...${NC}"
"$VENV/bin/pip" install --quiet --upgrade pip
"$VENV/bin/pip" install --quiet -e "$SCRIPT_DIR"
echo -e "  ${GREEN}✓ All packages installed${NC}"

echo -e "${BLUE}[4/5] Creating launcher...${NC}"
cat > "$SCRIPT_DIR/osint-tool" << WRAPPER
#!/usr/bin/env bash
SCRIPT_DIR="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
exec "\$SCRIPT_DIR/.venv/bin/osint-tool" "\$@"
WRAPPER
chmod +x "$SCRIPT_DIR/osint-tool"
echo -e "  ${GREEN}✓ ./osint-tool launcher ready${NC}"

echo -e "${BLUE}[5/5] Done!${NC}"
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗"
echo    "║                    HOW TO USE                        ║"
echo    "╠══════════════════════════════════════════════════════╣"
echo    "║                                                      ║"
echo    "║  Investigate a username:                             ║"
echo    "║    ./osint-tool johndoe                              ║"
echo    "║                                                      ║"
echo    "║  Investigate an email:                               ║"
echo    "║    ./osint-tool john@example.com                     ║"
echo    "║                                                      ║"
echo    "║  Investigate a website/domain:                       ║"
echo    "║    ./osint-tool example.com                          ║"
echo    "║                                                      ║"
echo    "║  Save HTML report:                                   ║"
echo    "║    ./osint-tool target --html                        ║"
echo    "║                                                      ║"
echo    "║  Save all formats:                                   ║"
echo    "║    ./osint-tool target --all-formats                 ║"
echo    "║                                                      ║"
echo    "║  Deep investigation:                                 ║"
echo    "║    ./osint-tool target --deep --html                 ║"
echo    "║                                                      ║"
echo    "║  View past investigations:                           ║"
echo    "║    ./osint-tool history                              ║"
echo    "║                                                      ║"
echo    "╠══════════════════════════════════════════════════════╣"
echo    "║  OPTIONAL — API keys for better results:             ║"
echo    "║                                                      ║"
echo    "║  GitHub (60 → 5,000 req/hr, free):                  ║"
echo    "║    export GITHUB_TOKEN=ghp_...                       ║"
echo    "║                                                      ║"
echo    "║  HaveIBeenPwned (breach data, ~$3.50/mo):           ║"
echo    "║    export HIBP_API_KEY=your_key                      ║"
echo    "║    Get: https://haveibeenpwned.com/API/Key            ║"
echo    "║                                                      ║"
echo    "║  URLScan.io (enhanced web scans, free tier):         ║"
echo    "║    export URLSCAN_API_KEY=your_key                   ║"
echo    "║    Get: https://urlscan.io/user/signup/              ║
echo    "║                                                      ║"
echo    "║  BuiltWith (tech stack database, free tier):         ║"
echo    "║    export BUILTWITH_API_KEY=your_key                 ║"
echo    "║    Get: https://builtwith.com/api                    ║"
echo    "║  (WhatRuns needs no key — works out of the box)      ║""
echo    "║                                                      ║"
echo    "║                                                      ║"
echo -e "╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}⚠  Use only on targets you are authorised to investigate.${NC}"
echo ""
