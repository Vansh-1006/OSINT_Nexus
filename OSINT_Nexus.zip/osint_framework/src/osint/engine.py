
"""Investigation Engine v2.1 — Quality-First
=============================================
Every setting prioritises completeness over speed.

Key quality settings:
  max_depth = 3           : full 3-hop pivot chain
  MAX_DOMAIN_PIVOTS = 8   : investigate up to 8 discovered domains
  MAX_USERNAME_PIVOTS = 3 : follow up to 3 discovered usernames
  provider_hard_cap = 120s: never kill a slow provider
  Subdomains still excluded from pivots (correct — they recursively cascade)
  Generic usernames still filtered (correct — avoids noise)
"""
from __future__ import annotations
import asyncio, time
from collections import deque
from datetime import datetime
from typing import Callable, Optional

from osint.config import Config
from osint.models import (
    Confidence, EntityType, Finding,
    InvestigationReport, InvestigationTarget,
    ProviderResult, ProviderStatus, TargetType,
)
from osint.providers.base import BaseProvider
from osint.providers.registry import load_providers
from osint.utils import detect_input_type, normalize_input

MAX_DOMAIN_PIVOTS   = 8
MAX_USERNAME_PIVOTS = 3

_CONF_ORDER = {
    Confidence.CONFIRMED: 0, Confidence.HIGH: 1,
    Confidence.MEDIUM: 2, Confidence.LOW: 3, Confidence.UNVERIFIED: 4,
}

_GENERIC_USERNAMES = {
    "admin","test","user","info","mail","email","contact","support",
    "hello","name","example","sample","anonymous","unknown","guest",
    "local","noreply","no-reply","postmaster","webmaster","root",
    "help","sales","office","team","staff","hr","legal","press",
}


def _make_target(value: str, hint: Optional[str] = None) -> InvestigationTarget:
    n = normalize_input(value)
    t = hint or detect_input_type(n)
    return InvestigationTarget(value=value, type=TargetType(t), normalized=n)


def _extract_pivots(
    finding: Finding,
    depth: int,
    domain_count: list[int],
    username_count: list[int],
) -> list[InvestigationTarget]:
    if not finding.is_pivotable():
        return []
    if finding.confidence not in {Confidence.CONFIRMED, Confidence.HIGH}:
        return []
    v  = finding.value.strip()
    et = finding.entity_type
    if not v or len(v) < 3:
        return []

    # Subdomains: NEVER pivot — they cascade into infinite recursive scans
    if et == EntityType.SUBDOMAIN:
        return []

    if et == EntityType.EMAIL:
        if "@" in v and "." in v.split("@")[-1]:
            return [_make_target(v, "email")]

    if et == EntityType.DOMAIN:
        if domain_count[0] >= MAX_DOMAIN_PIVOTS:
            return []
        clean = v.lstrip("*.").lower()
        if "." in clean and " " not in clean and len(clean) < 80:
            domain_count[0] += 1
            return [_make_target(clean, "domain")]

    if et == EntityType.WEBSITE and depth <= 1:
        if domain_count[0] >= MAX_DOMAIN_PIVOTS:
            return []
        try:
            from urllib.parse import urlparse
            host = urlparse(v if "://" in v else f"https://{v}").netloc
            host = host.lstrip("www.").lower()
            if "." in host and " " not in host and len(host) < 60:
                domain_count[0] += 1
                return [_make_target(host, "domain")]
        except Exception:
            pass

    if et == EntityType.USERNAME and depth <= 1:
        if username_count[0] >= MAX_USERNAME_PIVOTS:
            return []
        if " " in v or len(v) < 3:
            return []
        if v.lower() in _GENERIC_USERNAMES:
            return []
        username_count[0] += 1
        return [_make_target(v, "username")]

    return []


class InvestigationEngine:
    def __init__(self, config: Config,
                 progress_callback: Optional[Callable] = None,
                 deep_mode: bool = False):
        self.config     = config
        self._progress  = progress_callback or (lambda m, l: None)
        self._providers : list[BaseProvider] = []
        self._deep_mode = deep_mode

    def _log(self, msg: str, level: str = "info") -> None:
        self._progress(msg, level)

    async def investigate(self, raw_input: str) -> InvestigationReport:
        initial = _make_target(raw_input)
        report  = InvestigationReport(target=initial, started_at=datetime.utcnow())

        self._providers = load_providers(self.config)
        self._log(f"Loaded {len(self._providers)} providers", "info")

        max_depth    = self.config.max_depth          # 3 from config
        provider_cap = int(self.config.get(
            "investigation", "provider_hard_cap", default=120))

        if self._deep_mode:
            max_depth = max(max_depth, 4)
            for p in self._providers:
                if p.name == "duckduckgo":
                    p.config["max_queries"] = p.config.get("deep_max_queries", 8)

        queue : deque[tuple[InvestigationTarget, int]] = deque()
        queue.append((initial, 0))
        visited      : set[str]           = set()
        all_findings : list[Finding]      = []
        all_results  : list[ProviderResult] = []
        domain_count   = [0]
        username_count = [0]

        while queue:
            target, depth = queue.popleft()
            key = f"{target.type.value}:{target.normalized}"
            if key in visited:
                continue
            visited.add(key)
            report.pivots_explored.append(target.value)

            self._log(
                f"[depth {depth}] {target.type.value}: {target.value}",
                "start" if depth == 0 else "pivot")

            new_findings, results = await self._run_providers(target, provider_cap)
            all_findings.extend(new_findings)
            all_results.extend(results)

            if depth < max_depth:
                seen_pivots: set[str] = set()
                for f in new_findings:
                    for pivot in _extract_pivots(f, depth, domain_count, username_count):
                        pk = f"{pivot.type.value}:{pivot.normalized}"
                        if pk not in visited and pk not in seen_pivots:
                            seen_pivots.add(pk)
                            queue.append((pivot, depth + 1))

        report.findings         = self._dedup(all_findings)
        report.provider_results = all_results
        report.completed_at     = datetime.utcnow()
        report.summary          = self._summarise(report)

        for p in self._providers:
            try: await p.close()
            except Exception: pass

        return report

    async def _run_providers(self, target: InvestigationTarget,
                             provider_cap: int) -> tuple[list[Finding], list[ProviderResult]]:
        applicable = [p for p in self._providers if target.type.value in p.applies_to]
        if not applicable:
            return [], []

        sem = asyncio.Semaphore(self.config.concurrent_limit)

        async def run_one(provider: BaseProvider) -> ProviderResult:
            async with sem:
                try:
                    self._log(f"  ↳ {provider.name}", "provider")
                    cap = min(provider_cap, provider.timeout + 10)
                    result = await asyncio.wait_for(
                        provider.investigate(target), timeout=float(cap))
                    if result.findings:
                        self._log(f"    ✓ {provider.name}: {result.found_count} finding(s)", "found")
                    return result
                except asyncio.TimeoutError:
                    self._log(f"    ⚡ {provider.name}: timed out after {cap}s", "warn")
                    return ProviderResult(provider=provider.name,
                        status=ProviderStatus.FAILED, error=f"Timeout after {cap}s")
                except Exception as e:
                    return ProviderResult(provider=provider.name,
                        status=ProviderStatus.FAILED, error=str(e))

        results  = await asyncio.gather(*[run_one(p) for p in applicable])
        findings = [f for r in results for f in r.findings]
        return findings, list(results)

    @staticmethod
    def _dedup(findings: list[Finding]) -> list[Finding]:
        seen: dict[str, Finding] = {}
        for f in findings:
            key = (f"{f.source}:{f.category.value}:"
                   f"{f.value.lower()[:100]}:{(f.url or '')[:100]}")
            if key not in seen or (
                _CONF_ORDER[f.confidence] < _CONF_ORDER[seen[key].confidence]):
                seen[key] = f
        return list(seen.values())

    @staticmethod
    def _summarise(report: InvestigationReport) -> dict:
        by_cat  : dict[str, int] = {}
        by_conf : dict[str, int] = {}
        for f in report.findings:
            by_cat[f.category.value]    = by_cat.get(f.category.value, 0) + 1
            by_conf[f.confidence.value] = by_conf.get(f.confidence.value, 0) + 1
        return {
            "total_findings":   len(report.findings),
            "by_category":      by_cat,
            "by_confidence":    by_conf,
            "pivots_explored":  len(report.pivots_explored),
            "providers_run":    len(set(r.provider for r in report.provider_results)),
            "providers_ok":     sum(1 for r in report.provider_results if r.status.value == "success"),
            "providers_no_key": sum(1 for r in report.provider_results if r.status.value == "auth_required"),
            "duration_seconds": round(report.duration_seconds, 1),
        }
