
from __future__ import annotations
from pathlib import Path
from osint.models import InvestigationReport

def save(report: InvestigationReport, path: Path) -> Path:
    path.write_text(report.model_dump_json(indent=2), encoding="utf-8")
    return path

def to_string(report: InvestigationReport) -> str:
    return report.model_dump_json(indent=2)
