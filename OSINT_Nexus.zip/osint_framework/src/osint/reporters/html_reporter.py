
"""Self-contained HTML reporter with dark theme, tech stack section, entity graph."""
from __future__ import annotations
from pathlib import Path
from osint.models import Confidence, InvestigationReport

_CONF_BADGE = {
    Confidence.CONFIRMED: ("#22c55e","#000"),
    Confidence.HIGH:      ("#86efac","#000"),
    Confidence.MEDIUM:    ("#fbbf24","#000"),
    Confidence.LOW:       ("#d97706","#fff"),
    Confidence.UNVERIFIED:("#6b7280","#fff"),
}
_CAT_ICON = {
    "profile":"👤","breach":"🔓","domain":"🌐","dns":"🔍","certificate":"🔒",
    "repository":"📁","mention":"💬","image":"🖼","social":"🔗","developer":"💻",
    "historical":"🕰","search_result":"🔎","email":"✉","username":"🏷","archive":"📚",
    "organization":"🏢","technology":"⚙️","network":"📡","post":"💬","contact":"📞",
    "subdomain":"🌿",
}
_CAT_COLOUR = {
    "technology":"#22d3ee","breach":"#f87171","profile":"#67e8f9",
    "network":"#60a5fa","repository":"#4ade80","domain":"#facc15",
    "subdomain":"#a3e635","email":"#67e8f9","dns":"#fde68a",
}

def _e(t):
    return str(t).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")

def save(report: InvestigationReport, path: Path) -> Path:
    path.write_text(_render(report), encoding="utf-8"); return path

def _render(report: InvestigationReport) -> str:
    s   = report.summary
    tgt = report.target
    by_conf = s.get("by_confidence",{})
    by_cat  = s.get("by_category",{})

    # Mermaid graph
    mermaid = ["graph TD", f'  ROOT["🎯 {_e(tgt.value)}"]']
    nids: dict[str,str] = {"root":"ROOT"}; nc = [0]
    def nid(v):
        k = str(v)[:60]
        if k not in nids:
            nc[0] += 1; nids[k] = f"N{nc[0]}"
        return nids[k]
    for f in report.findings[:80]:
        icon  = _CAT_ICON.get(f.category.value,"•")
        label = _e(f.value[:35])
        pivot = f.pivot_from or tgt.value
        src   = nid(pivot); dst = nid(f.value)
        mermaid.append(f'  {dst}["{icon} {label}"]')
        mermaid.append(f'  {src} --> {dst}')

    # Tech stack section
    tech_items = report.findings_by_category.get("technology",[])
    tech_html = ""
    if tech_items:
        cats: dict[str,list] = {}
        for t in tech_items:
            c = t.metadata.get("category","Other")
            cats.setdefault(c,[]).append(t)
        tech_html = '<div class="tech-grid">'
        for cat, techs in sorted(cats.items()):
            tech_html += f'<div class="tech-cat"><h4>{_e(cat)}</h4>'
            for t in techs:
                bc, fc = _CONF_BADGE.get(t.confidence,("#888","#fff"))
                ver = t.metadata.get("version","")
                ver_str = f'<span class="ver">{_e(ver)}</span>' if ver else ""
                tech_html += (f'<div class="tech-pill" style="border-left:3px solid {bc}">'
                              f'<span class="tech-name">{_e(t.metadata.get("tech_name",t.value))}</span>'
                              f'{ver_str}'
                              f'<span class="conf-dot" style="background:{bc}" title="{t.confidence.value}"></span>'
                              f'</div>')
            tech_html += '</div>'
        tech_html += '</div>'

    # All findings
    findings_html = ""
    order = ["technology","profile","breach","email","network","repository","organization",
             "domain","subdomain","certificate","dns","post","social","search_result",
             "mention","archive","image","contact","historical","username"]
    by_cat_f = report.findings_by_category
    for cat in order + [c for c in by_cat_f if c not in order]:
        items = by_cat_f.get(cat,[])
        if not items: continue
        if cat == "technology": continue  # shown separately above
        icon   = _CAT_ICON.get(cat,"•")
        colour = _CAT_COLOUR.get(cat,"#94a3b8")
        findings_html += f'<div class="cat-section"><h3 style="color:{colour}">{icon} {_e(cat.replace("_"," ").title())} <span class="badge-count">{len(items)}</span></h3><div class="findings-grid">'
        for f in items:
            bc, fc = _CONF_BADGE.get(f.confidence,("#888","#fff"))
            url_html = f'<a href="{_e(f.url)}" target="_blank" class="finding-url">↗ {_e(f.url[:90])}</a>' if f.url else ""
            findings_html += (f'<div class="finding-card">'
                f'<div class="finding-header">'
                f'<span class="conf-badge" style="background:{bc};color:{fc}">{f.confidence.value}</span>'
                f'<span class="finding-source">{_e(f.source)}</span></div>'
                f'<div class="finding-value">{_e(f.value[:120])}</div>'
                f'{url_html}'
                f'<div class="finding-evidence">{_e(f.evidence[:280])}</div>'
                f'</div>')
        findings_html += '</div></div>'

    # Provider rows
    prows = ""
    seen: set[str] = set()
    for pr in report.provider_results:
        if pr.provider in seen: continue
        seen.add(pr.provider)
        from osint.models import ProviderStatus
        colour = {"success":"#22c55e","no_results":"#6b7280","auth_required":"#fbbf24",
                  "failed":"#ef4444","rate_limited":"#f97316","skipped":"#6b7280"}.get(pr.status.value,"#888")
        prows += (f"<tr><td>{_e(pr.provider)}</td>"
                  f'<td><span style="color:{colour};font-weight:600">{pr.status.value}</span></td>'
                  f"<td>{pr.found_count}</td><td>{pr.duration:.1f}s</td>"
                  f"<td>{_e(pr.error or '')}</td></tr>")

    return f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OSINT — {_e(tgt.value)}</title>
<style>
:root{{--bg:#0f172a;--sur:#1e293b;--sur2:#334155;--txt:#e2e8f0;--dim:#94a3b8;--acc:#38bdf8;--bdr:#334155}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--txt);font-family:'Segoe UI',system-ui,sans-serif;font-size:14px;line-height:1.6;padding:20px}}
h1{{font-size:1.8rem;color:var(--acc);margin-bottom:4px}}
h2{{font-size:1.1rem;color:var(--dim);font-weight:400;margin-bottom:20px}}
h3{{font-size:.95rem;margin:14px 0 8px}}
h4{{font-size:.8rem;color:var(--dim);text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}}
.meta{{display:flex;gap:20px;flex-wrap:wrap;padding:14px;background:var(--sur);border-radius:8px;border:1px solid var(--bdr);margin-bottom:20px}}
.meta-item .lbl{{color:var(--dim);font-size:10px;text-transform:uppercase;letter-spacing:.06em}}
.meta-item .val{{font-size:1.05rem;font-weight:600}}
.stats-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin-bottom:20px}}
.stat-card{{background:var(--sur);border:1px solid var(--bdr);border-radius:8px;padding:12px;text-align:center}}
.stat-card .num{{font-size:1.8rem;font-weight:700;color:var(--acc)}}
.stat-card .lbl{{font-size:10px;color:var(--dim);text-transform:uppercase}}
.section{{background:var(--sur);border:1px solid var(--bdr);border-radius:10px;padding:18px;margin-bottom:20px}}
.graph-wrap{{background:#0d1117;border-radius:8px;padding:14px;overflow:auto;min-height:250px}}
.tech-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px}}
.tech-cat{{background:var(--sur2);border-radius:8px;padding:12px}}
.tech-pill{{background:var(--bg);border-radius:6px;padding:8px 10px;margin-bottom:6px;display:flex;align-items:center;gap:8px}}
.tech-name{{font-weight:600;flex:1;font-size:13px}}
.ver{{font-size:11px;color:#22d3ee;background:#0e3a48;padding:1px 6px;border-radius:4px}}
.conf-dot{{width:8px;height:8px;border-radius:50%;flex-shrink:0}}
.badge-count{{background:var(--sur2);color:var(--dim);padding:1px 7px;border-radius:999px;font-size:10px;margin-left:6px}}
.findings-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:10px}}
.finding-card{{background:var(--sur2);border-radius:8px;padding:12px;display:flex;flex-direction:column;gap:5px}}
.finding-header{{display:flex;align-items:center;gap:7px}}
.conf-badge{{font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;letter-spacing:.04em}}
.finding-source{{font-size:10px;color:var(--dim)}}
.finding-value{{font-weight:600;font-size:13px;word-break:break-word}}
.finding-url{{font-size:11px;color:var(--acc);word-break:break-all;text-decoration:none}}
.finding-url:hover{{text-decoration:underline}}
.finding-evidence{{font-size:11px;color:var(--dim);word-break:break-word}}
table{{width:100%;border-collapse:collapse}}
th,td{{padding:8px 10px;text-align:left;border-bottom:1px solid var(--bdr);font-size:13px}}
th{{background:var(--sur2);color:var(--dim);font-size:10px;text-transform:uppercase;letter-spacing:.06em}}
.warn{{background:#1e1a0e;border:1px solid #92400e;border-radius:8px;padding:12px;color:#fbbf24;font-size:12px;margin-top:16px}}
footer{{text-align:center;color:var(--dim);font-size:11px;margin-top:24px;padding-top:12px;border-top:1px solid var(--bdr)}}
</style>
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>mermaid.initialize({{startOnLoad:true,theme:'dark',themeVariables:{{fontSize:'11px'}}}});</script>
</head><body>
<h1>🔍 OSINT Intelligence Report</h1>
<h2>Target: {_e(tgt.value)} &nbsp;·&nbsp; {tgt.type.value.upper()}</h2>
<div class="meta">
  <div class="meta-item"><div class="lbl">Report ID</div><div class="val">{report.id}</div></div>
  <div class="meta-item"><div class="lbl">Date</div><div class="val">{report.started_at.strftime('%Y-%m-%d %H:%M UTC')}</div></div>
  <div class="meta-item"><div class="lbl">Duration</div><div class="val">{s.get('duration_seconds',0):.1f}s</div></div>
  <div class="meta-item"><div class="lbl">Pivots</div><div class="val">{s.get('pivots_explored',0)}</div></div>
  <div class="meta-item"><div class="lbl">Total Findings</div><div class="val">{s.get('total_findings',0)}</div></div>
</div>
<div class="stats-grid">
  <div class="stat-card"><div class="num">{by_conf.get('CONFIRMED',0)}</div><div class="lbl">Confirmed</div></div>
  <div class="stat-card"><div class="num">{by_conf.get('HIGH',0)}</div><div class="lbl">High</div></div>
  <div class="stat-card"><div class="num">{by_conf.get('MEDIUM',0)}</div><div class="lbl">Medium</div></div>
  <div class="stat-card"><div class="num">{by_cat.get('technology',0)}</div><div class="lbl">Technologies</div></div>
  <div class="stat-card"><div class="num">{by_cat.get('profile',0)+by_cat.get('social',0)}</div><div class="lbl">Profiles</div></div>
  <div class="stat-card"><div class="num">{by_cat.get('repository',0)}</div><div class="lbl">Repos</div></div>
  <div class="stat-card"><div class="num">{by_cat.get('breach',0)}</div><div class="lbl">Breaches</div></div>
  <div class="stat-card"><div class="num">{by_cat.get('subdomain',0)+by_cat.get('domain',0)}</div><div class="lbl">Domains</div></div>
</div>
{'<div class="section"><h3>⚙️ Technology Stack</h3>' + tech_html + '</div>' if tech_html else ''}
<div class="section">
  <h3>🕸 Entity Graph</h3>
  <div class="graph-wrap"><pre class="mermaid">{chr(10).join(mermaid)}</pre></div>
</div>
<div class="section"><h3>📊 All Findings</h3>{findings_html}</div>
<div class="section"><h3>⚙️ Provider Status</h3>
<table><thead><tr><th>Provider</th><th>Status</th><th>Found</th><th>Time</th><th>Note</th></tr></thead>
<tbody>{prows}</tbody></table></div>
<div class="warn">⚠️ All findings are from publicly accessible sources only. A matching username does not confirm the same individual. This report is for authorised OSINT research only.</div>
<footer>Generated by OSINT Intelligence Framework v2.0 · {report.started_at.strftime('%Y-%m-%d')}</footer>
</body></html>"""
