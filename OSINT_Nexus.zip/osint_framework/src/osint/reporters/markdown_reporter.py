
from __future__ import annotations
from pathlib import Path
from osint.models import InvestigationReport

def save(report: InvestigationReport, path: Path) -> Path:
    path.write_text(to_string(report), encoding="utf-8"); return path

def to_string(report: InvestigationReport) -> str:
    s = report.summary; tgt = report.target
    lines = [
        "# OSINT Intelligence Report", "",
        f"| Field | Value |", f"|-------|-------|",
        f"| ID | `{report.id}` |",
        f"| Target | `{tgt.value}` |",
        f"| Type | {tgt.type.value} |",
        f"| Started | {report.started_at.strftime('%Y-%m-%d %H:%M UTC')} |",
        f"| Duration | {s.get('duration_seconds',0):.1f}s |",
        f"| Total Findings | **{s.get('total_findings',0)}** |", "",
        "## Confidence Breakdown", "",
        "| Confidence | Count |", "|------------|-------|",
    ]
    for c in ["CONFIRMED","HIGH","MEDIUM","LOW","UNVERIFIED"]:
        lines.append(f"| {c} | {s.get('by_confidence',{}).get(c,0)} |")
    lines += ["", "## Findings by Category", ""]
    for cat, items in sorted(report.findings_by_category.items()):
        lines.append(f"### {cat.replace('_',' ').title()} ({len(items)})\n")
        for f in items:
            url_str = f" — [{f.url}]({f.url})" if f.url else ""
            lines.append(f"- **[{f.confidence.value}]** `{f.value}`{url_str}")
            lines.append(f"  - *Source:* {f.source} | *Evidence:* {f.evidence[:200]}")
            lines.append("")
    lines += ["## Provider Status", "",
              "| Provider | Status | Found | Duration | Note |",
              "|----------|--------|-------|----------|------|"]
    seen: set[str] = set()
    for pr in report.provider_results:
        if pr.provider in seen: continue
        seen.add(pr.provider)
        lines.append(f"| {pr.provider} | {pr.status.value} | {pr.found_count} | {pr.duration:.1f}s | {pr.error or ''} |")
    lines += ["","---","> ⚠️ Authorised OSINT research only. Username match ≠ same individual."]
    return "\n".join(lines)
