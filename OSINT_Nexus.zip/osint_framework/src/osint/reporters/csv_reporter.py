
from __future__ import annotations
import csv
from pathlib import Path
from osint.models import InvestigationReport

def save(report: InvestigationReport, path: Path) -> Path:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id","source","category","entity_type","value","url","confidence","evidence","pivot_from","timestamp"])
        for f in report.findings:
            w.writerow([f.id, f.source, f.category.value, f.entity_type.value, f.value,
                        f.url or "", f.confidence.value, f.evidence.replace("\n"," "),
                        f.pivot_from or "", f.timestamp.isoformat()])
    return path
