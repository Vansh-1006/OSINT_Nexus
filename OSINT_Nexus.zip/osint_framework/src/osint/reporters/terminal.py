
"""Terminal reporter — rich formatted output."""
from __future__ import annotations
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from osint.models import Confidence, InvestigationReport, ProviderStatus

console = Console()

_CAT_COLOUR = {
    "profile":"cyan","breach":"red","domain":"yellow","dns":"yellow","certificate":"blue",
    "repository":"green","mention":"white","image":"magenta","social":"cyan","developer":"green",
    "historical":"dim","search_result":"white","email":"cyan","username":"cyan","archive":"dim",
    "organization":"yellow","technology":"bright_green","network":"blue","post":"white",
    "contact":"magenta","subdomain":"yellow",
}
_CONF_COLOUR = {
    Confidence.CONFIRMED:"bold green", Confidence.HIGH:"green",
    Confidence.MEDIUM:"yellow", Confidence.LOW:"dim yellow", Confidence.UNVERIFIED:"dim",
}
_CAT_ICON = {
    "profile":"👤","breach":"🔓","domain":"🌐","dns":"🔍","certificate":"🔒",
    "repository":"📁","mention":"💬","image":"🖼 ","social":"🔗","developer":"💻",
    "historical":"🕰 ","search_result":"🔎","email":"✉ ","username":"🏷 ","archive":"📚",
    "organization":"🏢","technology":"⚙️ ","network":"📡","post":"💬","contact":"📞",
    "subdomain":"🌿",
}

def render(report: InvestigationReport) -> None:
    s   = report.summary
    tgt = report.target
    console.print()
    console.print(Panel(
        f"[bold white]OSINT Intelligence Report[/bold white]\n"
        f"[dim]ID: {report.id}  ·  Target: [bright_white]{tgt.value}[/bright_white]  ·  "
        f"Type: [cyan]{tgt.type.value.upper()}[/cyan]  ·  "
        f"Duration: {s.get('duration_seconds',0):.1f}s  ·  "
        f"Pivots: {s.get('pivots_explored',0)}[/dim]",
        border_style="bright_blue", expand=False))
    console.print()

    # Stats
    by_cat  = s.get("by_category",{})
    by_conf = s.get("by_confidence",{})
    grid    = Table.grid(expand=False)
    grid.add_column(min_width=24); grid.add_column(min_width=24); grid.add_column(min_width=24)
    grid.add_row(f"[cyan]Profiles[/cyan]    : [bold]{by_cat.get('profile',0)+by_cat.get('social',0)}[/bold]",
                 f"[bright_green]Tech Stack[/bright_green] : [bold]{by_cat.get('technology',0)}[/bold]",
                 f"[green]Repos[/green]       : [bold]{by_cat.get('repository',0)}[/bold]")
    grid.add_row(f"[yellow]Domains[/yellow]     : [bold]{by_cat.get('domain',0)+by_cat.get('subdomain',0)}[/bold]",
                 f"[blue]Network[/blue]     : [bold]{by_cat.get('network',0)}[/bold]",
                 f"[red]Breaches[/red]    : [bold]{by_cat.get('breach',0)}[/bold]")
    grid.add_row(f"[cyan]Emails[/cyan]      : [bold]{by_cat.get('email',0)}[/bold]",
                 f"[white]Posts[/white]       : [bold]{by_cat.get('post',0)}[/bold]",
                 f"[dim]Archives[/dim]    : [bold]{by_cat.get('archive',0)}[/bold]")
    grid.add_row(f"[bold green]CONFIRMED[/bold green]   : [bold]{by_conf.get('CONFIRMED',0)}[/bold]",
                 f"[green]HIGH[/green]        : [bold]{by_conf.get('HIGH',0)}[/bold]",
                 f"[bold]TOTAL[/bold]       : [bold bright_white]{s.get('total_findings',0)}[/bold bright_white]")
    console.print(Panel(grid, title="[bold]SUMMARY[/bold]", border_style="bright_blue", expand=False))
    console.print()

    # Findings by category
    order = ["technology","profile","breach","email","repository","organization",
             "domain","subdomain","dns","certificate","network","post","social",
             "search_result","mention","archive","image","contact","historical","username"]
    by_cat_findings = report.findings_by_category
    for cat in order + [c for c in by_cat_findings if c not in order]:
        items = by_cat_findings.get(cat, [])
        if not items: continue
        colour = _CAT_COLOUR.get(cat,"white")
        icon   = _CAT_ICON.get(cat,"•")
        console.print(Rule(f"[bold {colour}]{icon} {cat.upper().replace('_',' ')}[/bold {colour}] — {len(items)}"))
        tbl = Table(show_header=True, header_style="bold", box=box.SIMPLE, expand=True)
        tbl.add_column("Confidence", width=12, no_wrap=True)
        tbl.add_column("Finding",    ratio=3)
        tbl.add_column("Source",     width=18, no_wrap=True)
        tbl.add_column("Evidence",   ratio=5, style="dim")
        for f in sorted(items, key=lambda x: list(Confidence).index(x.confidence)):
            ev = f.evidence[:130] + "…" if len(f.evidence) > 130 else f.evidence
            tbl.add_row(Text(f.confidence.value, style=_CONF_COLOUR.get(f.confidence,"white")),
                        Text(f.value, style=colour), Text(f.source, style="dim"), Text(ev))
        console.print(tbl)
        for f in items:
            if f.url and cat in {"profile","repository","technology","network","subdomain","certificate"}:
                console.print(f"    [dim blue]{f.url}[/dim blue]")
        console.print()

    # Provider status
    console.print(Rule("[bold]PROVIDER STATUS[/bold]"))
    ptbl = Table(show_header=True, header_style="bold", box=box.SIMPLE)
    ptbl.add_column("Provider", width=22); ptbl.add_column("Status", width=14)
    ptbl.add_column("Found", width=7, justify="right"); ptbl.add_column("Time", width=8, justify="right")
    ptbl.add_column("Note", ratio=1)
    seen: set[str] = set()
    for pr in report.provider_results:
        if pr.provider in seen: continue
        seen.add(pr.provider)
        st = pr.status
        stext = {
            ProviderStatus.SUCCESS:       Text("✓ ok",         "green"),
            ProviderStatus.NO_RESULTS:    Text("— none",        "dim"),
            ProviderStatus.AUTH_REQUIRED: Text("⚠ key needed",  "yellow"),
            ProviderStatus.RATE_LIMITED:  Text("⏳ rate limit",  "yellow"),
            ProviderStatus.SKIPPED:       Text("↷ skipped",     "dim"),
            ProviderStatus.FAILED:        Text("✗ failed",      "red"),
        }.get(st, Text(st.value))
        ptbl.add_row(pr.provider, stext, str(pr.found_count),
                     f"{pr.duration:.1f}s", Text(pr.error or "", style="dim"))
    console.print(ptbl)
    console.print()
    console.print(Panel(
        "[dim]All findings from publicly accessible sources only.\n"
        "Username match ≠ same individual — always verify independently.\n"
        "For authorised OSINT research only.[/dim]",
        border_style="dim", expand=False))
    console.print()
