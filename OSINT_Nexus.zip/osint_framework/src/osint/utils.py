from __future__ import annotations
import asyncio, hashlib, re, time
from typing import Optional

_EMAIL  = re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')
_DOMAIN = re.compile(r'^(?:[a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}$')

def detect_input_type(value: str) -> str:
    v = value.strip()
    if _EMAIL.match(v):  return 'email'
    if _DOMAIN.match(v) and '.' in v and not v.startswith('.'): return 'domain'
    return 'username'

def normalize_input(value: str) -> str:
    return value.strip().lower()

def decompose_email(email: str) -> dict:
    local, _, domain = email.partition('@')
    return {
        'email':          email,
        'local':          local,
        'domain':         domain,
        'username_guess': re.sub(r'[._+\-]','', local),
        'name_guess':     re.sub(r'[._+\-]',' ', local).strip(),
    }

def generate_search_queries(target: str, ttype: str) -> list[str]:
    q = []
    if ttype == 'email':
        q += [f'"{target}"', f'"{target}" profile', f'"{target}" contact',
              f'"{target}" github', f'"{target}" filetype:pdf']
        p = decompose_email(target)
        q += [f'"{p["local"]}" site:linkedin.com', f'"{p["local"]}" github']
    elif ttype == 'username':
        q += [f'"{target}"', f'"{target}" profile', f'"{target}" github',
              f'"{target}" linkedin', f'"{target}" about', f'"{target}" contact',
              f'site:github.com "{target}"', f'site:reddit.com "{target}"',
              f'"{target}" filetype:pdf']
    elif ttype == 'domain':
        q += [f'site:{target}', f'"{target}" admin', f'"{target}" contact',
              f'"{target}" email', f'inurl:{target}']
    return q

def gravatar_hash(email: str) -> str:
    return hashlib.md5(email.strip().lower().encode()).hexdigest()

def gravatar_url(email: str, size: int = 200) -> str:
    return f'https://www.gravatar.com/avatar/{gravatar_hash(email)}?s={size}&d=404'

def extract_emails(text: str) -> list[str]:
    return list(set(re.findall(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', text)))

def extract_phones(text: str) -> list[str]:
    """Match phone numbers with typical formatting. Conservative to avoid false positives."""
    pat = re.compile(
        r'(?<![\w@/#])(?:'
        r'\+\d{1,3}[\s\-.]?\(?\d{1,4}\)?[\s\-.]?\d{3,4}[\s\-.]?\d{3,4}'  # +1 (555) 123-4567
        r'|\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}'  # (555) 123-4567
        r'|\d{3}[\s\-.]\d{3}[\s\-.]\d{4}'  # 555 123 4567
        r')(?![\w/#])',
        re.I)
    return list(set(m.group(0).strip() for m in pat.finditer(text)))

def extract_domains(text: str) -> list[str]:
    pat = re.compile(r'\b(?:[a-zA-Z0-9\-]+\.)+(?:com|org|net|io|dev|co|uk|edu|gov|info|biz|me)\b')
    return list(set(pat.findall(text)))

class RateLimiter:
    def __init__(self, rate: float, burst: int = 1):
        self._rate   = rate
        self._burst  = burst
        self._tokens = float(burst)
        self._last   = time.monotonic()
        self._lock   = asyncio.Lock()

    async def acquire(self):
        async with self._lock:
            now = time.monotonic()
            self._tokens = min(self._burst, self._tokens + (now - self._last) * self._rate)
            self._last = now
            if self._tokens < 1:
                await asyncio.sleep((1 - self._tokens) / self._rate)
                self._tokens = 0
            else:
                self._tokens -= 1
