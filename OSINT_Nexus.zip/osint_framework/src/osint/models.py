from __future__ import annotations
import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field

class TargetType(str, Enum):
    EMAIL    = "email"
    USERNAME = "username"
    DOMAIN   = "domain"
    NAME     = "name"

class EntityType(str, Enum):
    USERNAME     = "username"
    EMAIL        = "email"
    DOMAIN       = "domain"
    SUBDOMAIN    = "subdomain"
    PROFILE      = "profile"
    REPOSITORY   = "repository"
    ORGANIZATION = "organization"
    IMAGE        = "image"
    MENTION      = "mention"
    IP_ADDRESS   = "ip_address"
    ALIAS        = "alias"
    WEBSITE      = "website"
    PERSON       = "person"
    BREACH       = "breach"
    CERTIFICATE  = "certificate"
    ARCHIVE      = "archive"
    DNS_RECORD   = "dns_record"
    TECHNOLOGY   = "technology"
    POST         = "post"
    PHONE        = "phone"
    ASN          = "asn"
    HOSTING      = "hosting"

class Confidence(str, Enum):
    CONFIRMED  = "CONFIRMED"
    HIGH       = "HIGH"
    MEDIUM     = "MEDIUM"
    LOW        = "LOW"
    UNVERIFIED = "UNVERIFIED"

class FindingCategory(str, Enum):
    PROFILE      = "profile"
    BREACH       = "breach"
    DOMAIN       = "domain"
    DNS          = "dns"
    CERTIFICATE  = "certificate"
    REPOSITORY   = "repository"
    MENTION      = "mention"
    IMAGE        = "image"
    SOCIAL       = "social"
    DEVELOPER    = "developer"
    HISTORICAL   = "historical"
    SEARCH       = "search_result"
    EMAIL        = "email"
    USERNAME     = "username"
    ARCHIVE      = "archive"
    ORGANIZATION = "organization"
    TECHNOLOGY   = "technology"
    NETWORK      = "network"
    POST         = "post"
    CONTACT      = "contact"
    SUBDOMAIN    = "subdomain"

class ProviderStatus(str, Enum):
    SUCCESS       = "success"
    FAILED        = "failed"
    SKIPPED       = "skipped"
    AUTH_REQUIRED = "auth_required"
    RATE_LIMITED  = "rate_limited"
    UNAVAILABLE   = "unavailable"
    NO_RESULTS    = "no_results"

class Finding(BaseModel):
    id:          str            = Field(default_factory=lambda: uuid.uuid4().hex[:10])
    source:      str
    category:    FindingCategory
    entity_type: EntityType
    value:       str
    url:         Optional[str]  = None
    confidence:  Confidence     = Confidence.UNVERIFIED
    evidence:    str            = ""
    metadata:    dict[str, Any] = Field(default_factory=dict)
    timestamp:   datetime       = Field(default_factory=datetime.utcnow)
    pivot_from:  Optional[str]  = None

    def is_pivotable(self) -> bool:
        return self.entity_type in {
            EntityType.EMAIL, EntityType.DOMAIN, EntityType.SUBDOMAIN,
            EntityType.USERNAME, EntityType.ALIAS, EntityType.WEBSITE,
        }

class ProviderResult(BaseModel):
    provider:      str
    status:        ProviderStatus = ProviderStatus.SUCCESS
    findings:      list[Finding]  = Field(default_factory=list)
    error:         Optional[str]  = None
    duration:      float          = 0.0
    requests_made: int            = 0

    @property
    def found_count(self) -> int:
        return len(self.findings)

class InvestigationTarget(BaseModel):
    value:      str
    type:       TargetType
    normalized: str

class InvestigationReport(BaseModel):
    id:               str                  = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    target:           InvestigationTarget
    started_at:       datetime             = Field(default_factory=datetime.utcnow)
    completed_at:     Optional[datetime]   = None
    findings:         list[Finding]        = Field(default_factory=list)
    provider_results: list[ProviderResult] = Field(default_factory=list)
    pivots_explored:  list[str]            = Field(default_factory=list)
    summary:          dict[str, Any]       = Field(default_factory=dict)

    @property
    def duration_seconds(self) -> float:
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return 0.0

    @property
    def findings_by_category(self) -> dict[str, list[Finding]]:
        result: dict[str, list[Finding]] = {}
        for f in self.findings:
            result.setdefault(f.category.value, []).append(f)
        return result
