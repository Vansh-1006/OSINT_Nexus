from __future__ import annotations
import os, re
from pathlib import Path
from typing import Any
import yaml

_ENV = re.compile(r'\$\{([^}]+)\}')

def _resolve(v):
    if isinstance(v, dict):  return {k: _resolve(x) for k,x in v.items()}
    if isinstance(v, list):  return [_resolve(x) for x in v]
    if isinstance(v, str):   return _ENV.sub(lambda m: os.environ.get(m.group(1),''), v)
    return v

def _merge(base, over):
    r = dict(base)
    for k,v in over.items():
        r[k] = _merge(r[k],v) if k in r and isinstance(r[k],dict) and isinstance(v,dict) else v
    return r

class Config:
    _DEF = Path(__file__).parent.parent.parent / 'config' / 'default_config.yaml'

    def __init__(self, user_path=None):
        with open(self._DEF) as f:
            self._data = yaml.safe_load(f) or {}
        if user_path:
            p = Path(user_path)
            if p.exists():
                with open(p) as f:
                    self._data = _merge(self._data, yaml.safe_load(f) or {})
        self._data = _resolve(self._data)

    def get(self, *keys, default=None):
        n = self._data
        for k in keys:
            if not isinstance(n, dict): return default
            n = n.get(k, default)
        return n

    def provider(self, name):
        return self._data.get('providers',{}).get(name,{})

    @property
    def max_depth(self):        return int(self.get('investigation','max_depth',default=2))
    @property
    def request_timeout(self):  return int(self.get('investigation','timeout',default=12))
    @property
    def concurrent_limit(self): return int(self.get('investigation','concurrent_limit',default=20))
    @property
    def output_dir(self):
        p = Path(self.get('output','directory',default='osint_reports'))
        p.mkdir(parents=True, exist_ok=True)
        return p
    @property
    def github_token(self):
        return os.environ.get('GITHUB_TOKEN') or self.get('providers','github','api_key',default='')
    @property
    def hibp_key(self):
        return os.environ.get('HIBP_API_KEY') or self.get('providers','breach','hibp_api_key',default='')
    @property
    def urlscan_key(self):
        return os.environ.get('URLSCAN_API_KEY') or self.get('providers','urlscan','api_key',default='')
