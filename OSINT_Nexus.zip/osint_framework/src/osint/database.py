
"""SQLite persistence for investigations."""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from typing import Optional
from sqlalchemy import Column, DateTime, Float, Integer, String, Text, create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from osint.models import InvestigationReport

class Base(DeclarativeBase): pass

class InvestigationRow(Base):
    __tablename__ = "investigations"
    id           = Column(String(20),  primary_key=True)
    target       = Column(String(255), nullable=False)
    target_type  = Column(String(50),  nullable=False)
    started_at   = Column(DateTime,    nullable=False)
    completed_at = Column(DateTime)
    duration     = Column(Float)
    total_found  = Column(Integer, default=0)
    report_json  = Column(Text, nullable=False)
    created_at   = Column(DateTime, default=datetime.utcnow)

class Database:
    def __init__(self, db_path="osint_investigations.db"):
        self._engine  = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread":False})
        Base.metadata.create_all(self._engine)
        self._Session = sessionmaker(bind=self._engine)

    def save(self, report: InvestigationReport):
        row = InvestigationRow(id=report.id, target=report.target.value,
            target_type=report.target.type.value, started_at=report.started_at,
            completed_at=report.completed_at, duration=report.duration_seconds,
            total_found=len(report.findings), report_json=report.model_dump_json())
        with self._Session() as s: s.merge(row); s.commit()

    def list_investigations(self):
        with self._Session() as s:
            rows = s.query(InvestigationRow).order_by(InvestigationRow.started_at.desc()).all()
            return [{"id":r.id,"target":r.target,"target_type":r.target_type,
                     "started_at":str(r.started_at),"duration":r.duration,"total_found":r.total_found}
                    for r in rows]

    def load(self, iid: str) -> Optional[InvestigationReport]:
        with self._Session() as s:
            row = s.get(InvestigationRow, iid)
            return InvestigationReport.model_validate_json(row.report_json) if row else None

    def delete(self, iid: str) -> bool:
        with self._Session() as s:
            row = s.get(InvestigationRow, iid)
            if not row: return False
            s.delete(row); s.commit(); return True
