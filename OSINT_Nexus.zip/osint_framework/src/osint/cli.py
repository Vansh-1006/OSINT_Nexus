
"""OSINT Framework CLI v2 — layman-friendly, works with single command."""
from __future__ import annotations
import asyncio, os, sys, time
from pathlib import Path
from typing import Optional
import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.rule import Rule
from rich.table import Table
from osint.config import Config
from osint.engine import InvestigationEngine
from osint.models import InvestigationReport
from osint.utils import detect_input_type

console = Console()

BANNER = """
╔══════════════════════════════════════════════════════╗
║     OSINT Intelligence Framework  v2.1               ║
║  Username · Email · Domain Footprint Discovery       ║
╚══════════════════════════════════════════════════════╝
"""

class DefaultGroup(click.Group):
    def parse_args(self, ctx, args):
        if args:
            first = next((a for a in args if not a.startswith("-")), None)
            if first and first not in self.commands:
                args = ["investigate"] + args
        return super().parse_args(ctx, args)

def _load_cfg(config_path):
    if not config_path:
        p = Path.home() / ".osint" / "config.yaml"
        if p.exists(): config_path = str(p)
    return Config(config_path)

def _save_outputs(report, out_dir, formats):
    from osint.reporters import json_reporter, html_reporter, markdown_reporter, csv_reporter
    slug = report.target.normalized.replace("@","_at_").replace(".","_")[:40]
    ts   = report.started_at.strftime("%Y%m%d_%H%M%S")
    base = out_dir / f"osint_{slug}_{ts}"
    saved = []
    done: set[str] = set()
    dispatch = {"json":(json_reporter.save,".json"),"html":(html_reporter.save,".html"),
                "markdown":(markdown_reporter.save,".md"),"md":(markdown_reporter.save,".md"),
                "csv":(csv_reporter.save,".csv")}
    for fmt in formats:
        fn, ext = dispatch.get(fmt,(None,None))
        if fn and ext not in done:
            p = Path(str(base)+ext); fn(report, p); saved.append(p); done.add(ext)
    return saved

def _run(target, config, depth, deep_mode=False):
    if depth is not None:
        config._data.setdefault("investigation",{})["max_depth"] = depth
    # Deep mode: 4 DDG queries instead of 2
    if deep_mode:
        config._data.setdefault("providers",{}).setdefault("search",{})["max_queries"] = 4
    progress = Progress(SpinnerColumn(), TextColumn("[blue]{task.description}"),
                        TimeElapsedColumn(), console=console, transient=True)
    tid = progress.add_task("Starting…", total=None)
    def cb(msg, level):
        icons = {"start":"🔍","pivot":"↪ ","provider":"  ·","found":"  ✓","warn":"⚡"}
        progress.update(tid, description=f"{icons.get(level,'')} {msg}"[:100])
    engine = InvestigationEngine(config=config, progress_callback=cb, deep_mode=deep_mode)
    with progress:
        return asyncio.run(engine.investigate(target))

@click.group(cls=DefaultGroup, context_settings={"help_option_names":["-h","--help"],"max_content_width":100})
def main():
    """OSINT Intelligence Framework — investigate emails, usernames, and domains."""

@main.command("investigate", short_help="Investigate a target [DEFAULT]")
@click.argument("target")
@click.option("--deep",        "-d", is_flag=True, help="Deep scan (3 pivot hops)")
@click.option("--quick",       "-q", is_flag=True, help="Quick scan (1 hop)")
@click.option("--html",              is_flag=True, help="Save HTML report")
@click.option("--json",              is_flag=True, help="Save JSON report")
@click.option("--markdown",    "-md",is_flag=True, help="Save Markdown report")
@click.option("--csv",               is_flag=True, help="Save CSV spreadsheet")
@click.option("--all-formats", "-a", is_flag=True, help="Save all formats (HTML+JSON+MD+CSV)")
@click.option("--output",      "-o", default=None,  help="Output directory [default: osint_reports/]")
@click.option("--config",      "-c", default=None,  help="Config YAML path")
@click.option("--no-terminal",       is_flag=True, help="Skip terminal display")
@click.option("--quiet",             is_flag=True, help="Minimal output")
def investigate_cmd(target, deep, quick, html, json, markdown, csv, all_formats,
                    output, config, no_terminal, quiet):
    """
    Investigate TARGET — auto-detects email, username, or domain.

    \b
    Examples:
      osint-tool johndoe
      osint-tool john@example.com --html --json
      osint-tool example.com --deep --all-formats
      osint-tool johndoe --output ~/reports/
    """
    cfg      = _load_cfg(config)
    target   = target.strip()
    detected = detect_input_type(target)
    depth    = 3 if deep else (1 if quick else None)

    if not quiet:
        console.print(f"[bold bright_blue]{BANNER}[/bold bright_blue]")
        console.print(f"  [bold]Target      :[/bold] [bright_white]{target}[/bright_white]")
        console.print(f"  [bold]Detected as :[/bold] [cyan]{detected.upper()}[/cyan]")
        console.print(f"  [bold]Depth       :[/bold] {4 if deep else (1 if quick else 3)} hops")
        console.print()
        console.print("  [dim]Investigating — 30–120 seconds depending on target…[/dim]\n")

    t0 = time.monotonic()
    try:
        report = _run(target, cfg, depth, deep_mode=deep)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]"); sys.exit(0)
    except Exception as e:
        console.print(f"\n[red]Error:[/red] {e}")
        if os.environ.get("OSINT_DEBUG"):
            import traceback; traceback.print_exc()
        sys.exit(1)

    if not no_terminal and not quiet:
        from osint.reporters import terminal
        terminal.render(report)

    if cfg.get("output","save_to_db",default=True):
        try:
            from osint.database import Database
            Database(cfg.output_dir / "investigations.db").save(report)
        except Exception: pass

    formats = (["html","json","markdown","csv"] if all_formats else
               [f for f,flag in [("html",html),("json",json),("markdown",markdown),("csv",csv)] if flag])
    if formats:
        out_dir = Path(output) if output else cfg.output_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        saved = _save_outputs(report, out_dir, formats)
        console.print(Rule("[bold]SAVED FILES[/bold]"))
        for p in saved:
            console.print(f"  [green]✓[/green] {p.resolve()}")
        console.print()

    if not quiet:
        console.print(f"  [dim]Done in {time.monotonic()-t0:.1f}s — "
                      f"{report.summary.get('total_findings',0)} findings.[/dim]\n")

@main.command("providers", short_help="List all providers")
@click.option("--config","-c",default=None)
def providers_cmd(config):
    """List all available providers and their status."""
    cfg = _load_cfg(config)
    from osint.providers.registry import load_providers, provider_summary
    console.print(f"[bold bright_blue]{BANNER}[/bold bright_blue]")
    tbl = Table(title="Providers", show_lines=True)
    tbl.add_column("Name",      style="cyan",  width=22)
    tbl.add_column("Applies To",style="white", width=22)
    tbl.add_column("API Key",   style="yellow",width=10)
    tbl.add_column("Enabled",   style="green", width=8)
    tbl.add_column("Description",style="dim")
    for p in provider_summary(load_providers(cfg)):
        tbl.add_row(p["name"],", ".join(p["applies_to"]),
                    "Required" if p["requires_key"] else "Optional",
                    "✓" if p["enabled"] else "✗", p["description"])
    console.print(tbl)

@main.command("history", short_help="List past investigations")
@click.option("--config","-c",default=None)
def history_cmd(config):
    """List all saved investigations."""
    cfg = _load_cfg(config)
    db_path = cfg.output_dir / "investigations.db"
    if not db_path.exists():
        console.print("[dim]No investigations found.[/dim]"); return
    from osint.database import Database
    rows = Database(db_path).list_investigations()
    if not rows:
        console.print("[dim]No investigations found.[/dim]"); return
    tbl = Table(title="Investigation History",show_lines=False)
    tbl.add_column("ID",      style="cyan",  width=14)
    tbl.add_column("Target",  style="white", width=32)
    tbl.add_column("Type",    style="dim",   width=10)
    tbl.add_column("Date",    style="dim",   width=20)
    tbl.add_column("Findings",style="green", width=9, justify="right")
    for r in rows:
        tbl.add_row(r["id"],r["target"],r["target_type"],
                    r["started_at"][:19].replace("T"," "),str(r["total_found"]))
    console.print(tbl)
    console.print("\n  [dim]osint-tool show <ID>  to view a report.[/dim]\n")

@main.command("show", short_help="Show a saved report")
@click.argument("report_id")
@click.option("--json","-j",is_flag=True,help="Raw JSON output")
@click.option("--config","-c",default=None)
def show_cmd(report_id, json, config):
    """Display a saved investigation report."""
    cfg = _load_cfg(config)
    db_path = cfg.output_dir / "investigations.db"
    if not db_path.exists():
        console.print("[red]No database found.[/red]"); sys.exit(1)
    from osint.database import Database
    report = Database(db_path).load(report_id)
    if not report:
        console.print(f"[red]Report '{report_id}' not found.[/red]"); sys.exit(1)
    if json:
        from osint.reporters import json_reporter
        console.print(json_reporter.to_string(report))
    else:
        from osint.reporters import terminal
        terminal.render(report)

@main.command("export", short_help="Export a saved report")
@click.argument("report_id")
@click.option("--format","-f","fmt",type=click.Choice(["html","json","markdown","csv"],case_sensitive=False),default="html")
@click.option("--output","-o",default=".")
@click.option("--config","-c",default=None)
def export_cmd(report_id, fmt, output, config):
    """Export a saved investigation to file."""
    cfg = _load_cfg(config)
    from osint.database import Database
    report = Database(cfg.output_dir/"investigations.db").load(report_id)
    if not report:
        console.print(f"[red]Not found: {report_id}[/red]"); sys.exit(1)
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    for p in _save_outputs(report, out, [fmt]):
        console.print(f"[green]✓[/green] {p.resolve()}")

@main.command("delete", short_help="Delete a saved investigation")
@click.argument("report_id")
@click.option("--config","-c",default=None)
@click.confirmation_option(prompt="Delete this investigation?")
def delete_cmd(report_id, config):
    """Delete an investigation from the database."""
    cfg = _load_cfg(config)
    from osint.database import Database
    if Database(cfg.output_dir/"investigations.db").delete(report_id):
        console.print(f"[green]✓[/green] Deleted.")
    else:
        console.print(f"[red]Not found.[/red]"); sys.exit(1)

if __name__ == "__main__":
    main()
