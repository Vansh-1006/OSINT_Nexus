
"""URLScan.io — deep web scan with tech stack, screenshots, DOM, links (free API)."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class URLScanProvider(BaseProvider):
    name        = "urlscan"
    description = "URLScan.io — web scan results: tech stack, IPs, certificates, links"
    applies_to  = ["domain","username","email"]

    def __init__(self, config):
        super().__init__(config)
        self._api_key = config.get("api_key","")

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start    = time.monotonic()
        findings : list[Finding] = []
        reqs     = 0

        if target.type.value == "domain":
            q = f"page.domain:{target.normalized}"
        elif target.type.value == "email":
            q = f"page.domain:{target.normalized.split('@')[1]}"
        else:
            q = f'"{target.normalized}"'

        hdrs = {"Content-Type":"application/json"}
        if self._api_key:
            hdrs["API-Key"] = self._api_key

        try:
            r = await self.client.get(
                f"https://urlscan.io/api/v1/search/?q={q}&size=5",
                headers=hdrs, timeout=20)
            reqs += 1
            if r.status_code == 429:
                return ProviderResult(provider=self.name, status=ProviderStatus.RATE_LIMITED,
                                      error="URLScan.io rate limit", duration=self._timed(start), requests_made=reqs)
            if r.status_code != 200:
                return ProviderResult(provider=self.name, status=ProviderStatus.NO_RESULTS,
                                      duration=self._timed(start), requests_made=reqs)
            data = r.json()
        except Exception as e:
            return self._fail(str(e))

        for result in data.get("results",[])[:5]:
            page  = result.get("page",{})
            meta  = result.get("meta",{})
            task  = result.get("task",{})
            scan_url = f"https://urlscan.io/result/{result.get('_id','')}/"

            # Page info
            p_url  = page.get("url","")
            p_ip   = page.get("ip","")
            p_serv = page.get("server","")
            p_asn  = page.get("asnname","")
            p_country = page.get("country","")

            ev = (f"URLScan.io scan result for {target.value} | "
                  f"URL: {p_url[:80]} | IP: {p_ip} | Server: {p_serv} | "
                  f"ASN: {p_asn} | Country: {p_country}")

            findings.append(Finding(source="urlscan", category=FindingCategory.DOMAIN,
                entity_type=EntityType.WEBSITE, value=p_url[:120] or target.value,
                url=scan_url, confidence=Confidence.HIGH, evidence=ev,
                pivot_from=target.value, metadata={
                    "scan_url": scan_url, "page_ip": p_ip, "server": p_serv,
                    "asn": p_asn, "country": p_country, "screenshot": task.get("screenshotURL")}))

            # Tech stack from Wappalyzer data embedded in URLScan
            techs = meta.get("processors",{}).get("wappa",{}).get("data",[])
            for tech in techs:
                tname = tech.get("app","") or tech.get("name","")
                cats  = [c.get("name","") for c in tech.get("categories",[])]
                if tname:
                    findings.append(Finding(source="urlscan", category=FindingCategory.TECHNOLOGY,
                        entity_type=EntityType.TECHNOLOGY, value=tname,
                        url=scan_url, confidence=Confidence.HIGH,
                        evidence=f"Technology detected by URLScan/Wappalyzer: {tname} ({', '.join(cats)})",
                        pivot_from=target.value, metadata={"categories":cats,"from_scan":scan_url}))

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
