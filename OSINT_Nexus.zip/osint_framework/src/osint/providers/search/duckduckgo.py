
"""DuckDuckGo HTML search — 5 queries normal, 8 deep, 2s delay for reliability."""
from __future__ import annotations
import asyncio, re, time
from urllib.parse import unquote
import httpx
from bs4 import BeautifulSoup
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider
from osint.utils import generate_search_queries

class DuckDuckGoProvider(BaseProvider):
    name        = "duckduckgo"
    description = "DuckDuckGo HTML search — 5 queries, 2s delay for maximum reliability"
    applies_to  = ["username", "email", "domain"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start    = time.monotonic()
        queries  = generate_search_queries(target.value, target.type.value)
        max_q    = self.config.get("max_queries", 5)
        delay    = self.config.get("delay_between_queries", 2.0)
        findings : list[Finding] = []
        seen_urls: set[str]      = set()

        for i, query in enumerate(queries[:max_q]):
            for r in await self._search(query):
                if r["url"] not in seen_urls:
                    seen_urls.add(r["url"])
                    findings.append(Finding(
                        source="duckduckgo", category=FindingCategory.SEARCH,
                        entity_type=EntityType.MENTION, value=r["title"],
                        url=r["url"], confidence=Confidence.LOW,
                        evidence=f"Search: {query}\n{r['snippet'][:200]}",
                        pivot_from=target.value,
                        metadata={"query": query, "snippet": r["snippet"],
                                  "domain": r.get("domain", "")}))
            if i < max_q - 1:
                await asyncio.sleep(delay)

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start),
            requests_made=min(len(queries), max_q))

    async def _search(self, query: str) -> list[dict]:
        results: list[dict] = []
        try:
            r = await self.client.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query, "b": "", "kl": "us-en"},
                headers={"Content-Type": "application/x-www-form-urlencoded",
                         "Referer": "https://duckduckgo.com/",
                         "Origin":  "https://duckduckgo.com"},
                timeout=self.timeout)
            if r.status_code != 200: return results
            soup = BeautifulSoup(r.text, "lxml")
            for res in soup.select(".result__body"):
                title_el   = res.select_one(".result__title a")
                snippet_el = res.select_one(".result__snippet")
                if not title_el: continue
                href = title_el.get("href", "")
                m    = re.search(r"uddg=([^&]+)", href)
                url  = unquote(m.group(1)) if m else (href if href.startswith("http") else "")
                if not url: continue
                from urllib.parse import urlparse
                domain = urlparse(url).netloc.lstrip("www.")
                if "duckduckgo.com" in domain: continue
                results.append({"title": title_el.get_text(strip=True), "url": url,
                    "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                    "domain": domain})
        except Exception:
            pass
        return results
