
"""Email intelligence — Gravatar avatar lookup, email decomposition pivots."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider
from osint.utils import decompose_email, gravatar_url, gravatar_hash

class EmailIntelProvider(BaseProvider):
    name       = "email_intel"
    description= "Email decomposition + Gravatar avatar + pivot generation"
    applies_to = ["email"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "email":
            return self._skip("Only for email targets")
        start    = time.monotonic()
        email    = target.normalized
        findings : list[Finding] = []
        parts    = decompose_email(email)

        # Username pivot
        if parts["local"]:
            findings.append(Finding(source="email_intel", category=FindingCategory.USERNAME,
                entity_type=EntityType.USERNAME, value=parts["local"],
                confidence=Confidence.HIGH,
                evidence=f"Local part of email {email} — high probability username",
                pivot_from=email))
        if parts["username_guess"] != parts["local"]:
            findings.append(Finding(source="email_intel", category=FindingCategory.USERNAME,
                entity_type=EntityType.USERNAME, value=parts["username_guess"],
                confidence=Confidence.MEDIUM,
                evidence=f"Normalised username from email local part '{parts['local']}'",
                pivot_from=email))

        # Name pivot
        if " " in parts["name_guess"]:
            findings.append(Finding(source="email_intel", category=FindingCategory.PROFILE,
                entity_type=EntityType.PERSON, value=parts["name_guess"].title(),
                confidence=Confidence.LOW,
                evidence=f"Possible name inferred from email local part: {parts['local']}",
                pivot_from=email))

        # Domain pivot
        findings.append(Finding(source="email_intel", category=FindingCategory.DOMAIN,
            entity_type=EntityType.DOMAIN, value=parts["domain"],
            url=f"https://{parts['domain']}", confidence=Confidence.CONFIRMED,
            evidence=f"Domain portion of email {email}",
            pivot_from=email))

        # Gravatar
        avatar_url  = gravatar_url(email)
        g_hash      = gravatar_hash(email)
        profile_url = f"https://www.gravatar.com/{g_hash}.json"
        try:
            r = await self.client.get(avatar_url, timeout=8)
            if r.status_code == 200 and "image" in r.headers.get("content-type",""):
                findings.append(Finding(source="email_intel", category=FindingCategory.IMAGE,
                    entity_type=EntityType.IMAGE, value=f"Gravatar avatar for {email}",
                    url=avatar_url, confidence=Confidence.CONFIRMED,
                    evidence=f"Public Gravatar avatar exists for this email. MD5: {g_hash}",
                    pivot_from=email, metadata={"avatar_url":avatar_url,"md5":g_hash}))
            r2 = await self.client.get(profile_url, timeout=8)
            if r2.status_code == 200:
                entry = r2.json().get("entry",[{}])[0]
                if entry.get("displayName"):
                    findings.append(Finding(source="email_intel", category=FindingCategory.PROFILE,
                        entity_type=EntityType.PERSON, value=entry["displayName"],
                        url=f"https://www.gravatar.com/{g_hash}",
                        confidence=Confidence.HIGH,
                        evidence=f"Display name from public Gravatar profile for {email}",
                        pivot_from=email))
                for u in entry.get("urls",[]):
                    if u.get("value"):
                        findings.append(Finding(source="email_intel", category=FindingCategory.DOMAIN,
                            entity_type=EntityType.WEBSITE, value=u["value"], url=u["value"],
                            confidence=Confidence.HIGH, evidence=f"URL in Gravatar profile for {email}",
                            pivot_from=email))
        except Exception:
            pass

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS, findings=findings,
            duration=self._timed(start), requests_made=2)
