
from __future__ import annotations
import time
from abc import ABC, abstractmethod
from typing import Optional
import httpx
from osint.models import InvestigationTarget, ProviderResult, ProviderStatus

_UA = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36')
_HEADERS = {
    'User-Agent': _UA,
    'Accept': 'text/html,application/xhtml+xml,application/json,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
}

class BaseProvider(ABC):
    name:         str       = 'base'
    description:  str       = ''
    requires_key: bool      = False
    applies_to:   list[str] = ['username', 'email', 'domain']

    def __init__(self, config: dict):
        self.config  = config
        self.enabled = config.get('enabled', True)
        self.timeout = config.get('timeout', 6)
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                # connect=2s (was 6s) — fail fast on unreachable hosts
                timeout=httpx.Timeout(self.timeout, connect=2.0),
                follow_redirects=True,
                headers=_HEADERS,
                http2=True,   # multiplexed connections — faster on modern servers
                limits=httpx.Limits(
                    max_keepalive_connections=20,
                    max_connections=50,
                    keepalive_expiry=10,
                ),
            )
        return self._client

    @abstractmethod
    async def investigate(self, target: InvestigationTarget) -> ProviderResult: ...

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose(); self._client = None

    async def __aenter__(self): return self
    async def __aexit__(self, *_): await self.close()

    def _skip(self, r=''):   return ProviderResult(provider=self.name, status=ProviderStatus.SKIPPED,       error=r)
    def _nokey(self, r=''):  return ProviderResult(provider=self.name, status=ProviderStatus.AUTH_REQUIRED, error=r)
    def _fail(self, r=''):   return ProviderResult(provider=self.name, status=ProviderStatus.FAILED,        error=r)
    def _timed(self, t: float) -> float: return round(time.monotonic() - t, 3)
