
"""HaveIBeenPwned breach detection (paid API key required)."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class HibpProvider(BaseProvider):
    name         = "hibp"
    description  = "HaveIBeenPwned breach indicator (API key: haveibeenpwned.com/API/Key)"
    requires_key = True
    applies_to   = ["email"]

    def __init__(self, config):
        super().__init__(config)
        self._key = config.get("hibp_api_key","")

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "email": return self._skip("HIBP email only")
        if not self._key: return self._nokey("Set HIBP_API_KEY env var — https://haveibeenpwned.com/API/Key")
        start = time.monotonic(); email = target.normalized; findings = []
        try:
            r = await self.client.get(f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}",
                params={"truncateResponse":"false"},
                headers={"hibp-api-key":self._key,"User-Agent":"osint-framework/2.0"},
                timeout=15)
            if r.status_code == 401: return self._nokey("Invalid HIBP API key")
            if r.status_code == 429:
                return ProviderResult(provider=self.name, status=ProviderStatus.RATE_LIMITED,
                                      error="HIBP rate limited", duration=self._timed(start), requests_made=1)
            if r.status_code == 404:
                return ProviderResult(provider=self.name, status=ProviderStatus.NO_RESULTS,
                                      duration=self._timed(start), requests_made=1)
            if r.status_code == 200:
                for b in r.json():
                    dc = ", ".join(b.get("DataClasses",[]))
                    findings.append(Finding(source="hibp", category=FindingCategory.BREACH,
                        entity_type=EntityType.BREACH, value=b.get("Name","Unknown breach"),
                        url=f"https://haveibeenpwned.com/PwnedWebsites#{b.get('Name','')}",
                        confidence=Confidence.CONFIRMED,
                        evidence=(f"Email found in breach: {b.get('Title','?')} | "
                                  f"Date: {b.get('BreachDate','?')} | "
                                  f"Records: {b.get('PwnCount',0):,} | "
                                  f"Data exposed: {dc} | Verified: {b.get('IsVerified',False)}"),
                        pivot_from=email, metadata={
                            "breach_name":b.get("Name"),"breach_date":b.get("BreachDate"),
                            "pwn_count":b.get("PwnCount"),"data_classes":b.get("DataClasses",[]),
                            "is_verified":b.get("IsVerified"),"domain":b.get("Domain")}))
        except Exception as e:
            return self._fail(str(e))
        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=1)
