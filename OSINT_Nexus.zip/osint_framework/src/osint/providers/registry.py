
"""Provider registry — loads and returns all enabled providers."""
from __future__ import annotations
from typing import TYPE_CHECKING
from osint.providers.base import BaseProvider
if TYPE_CHECKING:
    from osint.config import Config

def load_providers(config: "Config") -> list[BaseProvider]:
    import os
    from osint.providers.email.gravatar             import EmailIntelProvider
    from osint.providers.usernames.platform_checker import PlatformCheckerProvider
    from osint.providers.developer.github           import GitHubProvider
    from osint.providers.search.duckduckgo          import DuckDuckGoProvider
    from osint.providers.search.urlscan             import URLScanProvider
    from osint.providers.certificates.crtsh         import CrtShProvider
    from osint.providers.archives.wayback           import WaybackProvider
    from osint.providers.domain.dns_provider        import DnsProvider
    from osint.providers.domain.rdap_provider       import RdapProvider
    from osint.providers.domain.web_fingerprint     import WebFingerprintProvider
    from osint.providers.domain.web_content         import WebContentProvider
    from osint.providers.domain.ip_intel            import IPIntelProvider
    from osint.providers.domain.subdomain_enum      import SubdomainEnumProvider
    from osint.providers.domain.builtwith           import BuiltWithProvider
    from osint.providers.domain.whatruns            import WhatRunsProvider
    from osint.providers.breach.hibp                import HibpProvider
    from osint.providers.social.reddit_provider     import RedditProvider
    from osint.providers.social.hackernews          import HackerNewsProvider

    builtwith_key = (os.environ.get("BUILTWITH_API_KEY")
                     or config.get("providers","builtwith","api_key", default=""))

    specs = [
        # ── Email ─────────────────────────────────────────────────────────
        (EmailIntelProvider,       "email",           {}),
        # ── Username ──────────────────────────────────────────────────────
        (PlatformCheckerProvider,  "usernames",       {}),
        # ── Developer ─────────────────────────────────────────────────────
        (GitHubProvider,           "github",          {"api_key": config.github_token}),
        # ── Social ────────────────────────────────────────────────────────
        (RedditProvider,           "reddit",          {}),
        (HackerNewsProvider,       "hackernews",      {}),
        # ── Domain — technology fingerprinting (3 engines + our own) ──────
        (WebFingerprintProvider,   "web_fingerprint", {}),   # our pattern engine
        (WhatRunsProvider,         "whatruns",        {}),   # WhatRuns (no key)
        (BuiltWithProvider,        "builtwith",       {"api_key": builtwith_key}),
        (URLScanProvider,          "urlscan",         {"api_key": config.urlscan_key}),
        # ── Domain — content + infrastructure ─────────────────────────────
        (WebContentProvider,       "web_content",     {}),
        (IPIntelProvider,          "ip_intel",        {}),
        (SubdomainEnumProvider,    "subdomain_enum",  {}),
        # ── DNS + RDAP + Certificates ─────────────────────────────────────
        (DnsProvider,              "dns",             {}),
        (RdapProvider,             "rdap",            {}),
        (CrtShProvider,            "certificates",    {}),
        # ── Archives + Search ─────────────────────────────────────────────
        (WaybackProvider,          "archives",        {}),
        (DuckDuckGoProvider,       "search",          {}),
        # ── Breach ────────────────────────────────────────────────────────
        (HibpProvider,             "breach",          {"hibp_api_key": config.hibp_key}),
    ]

    providers: list[BaseProvider] = []
    for cls, key, extra in specs:
        cfg = dict(config.provider(key))
        cfg.update(extra)
        cfg.setdefault("timeout", config.request_timeout)
        p = cls(cfg)
        if p.enabled:
            providers.append(p)
    return providers

def provider_summary(providers: list[BaseProvider]) -> list[dict]:
    return [{"name": p.name, "description": p.description,
             "requires_key": p.requires_key, "applies_to": p.applies_to,
             "enabled": p.enabled} for p in providers]
