
"""Passive subdomain enumeration — crt.sh + HackerTarget, concurrent, 30s timeout."""
from __future__ import annotations
import asyncio, time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class SubdomainEnumProvider(BaseProvider):
    name        = "subdomain_enum"
    description = "Passive subdomain discovery — crt.sh + HackerTarget (concurrent)"
    applies_to  = ["domain"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("Domain only")
        start  = time.monotonic()
        domain = target.normalized
        subs   : set[str] = set()

        async def fetch_crtsh():
            try:
                r = await self.client.get(
                    f"https://crt.sh/?q=%.{domain}&output=json",
                    timeout=self.timeout)
                if r.status_code == 200:
                    for entry in r.json():
                        for name in entry.get("name_value", "").splitlines():
                            n = name.strip().lower().lstrip("*.")
                            if n.endswith(f".{domain}") or n == domain:
                                subs.add(n)
            except Exception:
                pass

        async def fetch_hackertarget():
            try:
                r = await self.client.get(
                    f"https://api.hackertarget.com/hostsearch/?q={domain}",
                    timeout=self.timeout)
                if r.status_code == 200 and "error" not in r.text.lower()[:50]:
                    for line in r.text.splitlines():
                        parts = line.split(",")
                        if parts:
                            sub = parts[0].strip().lower()
                            if sub.endswith(f".{domain}") or sub == domain:
                                subs.add(sub)
            except Exception:
                pass

        await asyncio.gather(fetch_crtsh(), fetch_hackertarget())

        findings = []
        for sub in sorted(subs):
            if sub == domain:
                continue
            findings.append(Finding(
                source="subdomain_enum", category=FindingCategory.SUBDOMAIN,
                entity_type=EntityType.SUBDOMAIN, value=sub,
                url=f"https://{sub}", confidence=Confidence.CONFIRMED,
                evidence=f"Subdomain of {domain} — passive enumeration (crt.sh + HackerTarget)",
                pivot_from=domain, metadata={"parent_domain": domain}))

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=2)
