
"""RDAP domain registration intelligence."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class RdapProvider(BaseProvider):
    name        = "rdap"
    description = "RDAP domain registration — registrar, dates, nameservers, status"
    applies_to  = ["domain","email"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start  = time.monotonic()
        domain = target.normalized.split("@")[-1] if target.type.value=="email" else target.normalized
        try:
            r = await self.client.get(f"https://rdap.org/domain/{domain}",
                headers={"Accept":"application/rdap+json,application/json"}, timeout=15)
            if r.status_code != 200:
                return ProviderResult(provider=self.name, status=ProviderStatus.NO_RESULTS,
                                      duration=self._timed(start), requests_made=1)
            data     = r.json()
            findings = self._parse(data, domain)
        except Exception as e:
            return self._fail(str(e))
        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=1)

    def _parse(self, d, domain):
        findings = []
        registrar = ""
        for ent in d.get("entities",[]):
            if "registrar" in ent.get("roles",[]):
                vc = ent.get("vcardArray",[])
                if len(vc)>1:
                    for item in vc[1]:
                        if item[0]=="fn": registrar=item[3]; break
        events  = {e["eventAction"]:e["eventDate"] for e in d.get("events",[])}
        ns      = [n.get("ldhName","").lower() for n in d.get("nameservers",[])]
        status  = d.get("status",[])
        created = events.get("registration","?")
        expires = events.get("expiration","?")
        updated = events.get("last changed","?")
        summary = (f"Registered: {created} | Expires: {expires} | "
                   f"Registrar: {registrar or 'Redacted/Privacy'} | "
                   f"Status: {', '.join(status)} | Nameservers: {', '.join(ns[:3])}")
        findings.append(Finding(source="rdap", category=FindingCategory.DOMAIN,
            entity_type=EntityType.DOMAIN, value=domain,
            url=f"https://rdap.org/domain/{domain}", confidence=Confidence.CONFIRMED,
            evidence=summary, pivot_from=domain, metadata={
                "registrar":created, "created":created, "expires":expires,
                "updated":updated, "status":status, "nameservers":ns}))
        for ns_name in ns:
            if ns_name:
                findings.append(Finding(source="rdap", category=FindingCategory.DNS,
                    entity_type=EntityType.DOMAIN, value=ns_name,
                    confidence=Confidence.CONFIRMED, evidence=f"Nameserver for {domain}",
                    pivot_from=domain, metadata={"record_type":"NS","domain":domain}))
        return findings
