
"""IP Intelligence — resolves domain IPs and fetches geolocation, ASN, hosting info."""
from __future__ import annotations
import asyncio, time
import dns.asyncresolver, dns.resolver, dns.exception
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class IPIntelProvider(BaseProvider):
    name        = "ip_intel"
    description = "IP geolocation, ASN, hosting provider, reverse DNS (ip-api.com, free)"
    applies_to  = ["domain"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("Only applies to domain targets")
        start    = time.monotonic()
        domain   = target.normalized
        findings : list[Finding] = []
        reqs     = 0

        # Resolve IPs
        ips: list[str] = []
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = 5; resolver.lifetime = 8
        for rtype in ["A", "AAAA"]:
            try:
                ans = await resolver.resolve(domain, rtype)
                ips += [str(r) for r in ans]
                reqs += 1
            except Exception:
                pass

        # Geo + ASN per IP (ip-api.com, free, 45 req/min)
        sem = asyncio.Semaphore(3)
        async def lookup(ip: str):
            async with sem:
                try:
                    url = f"http://ip-api.com/json/{ip}?fields=status,country,countryCode,regionName,city,isp,org,as,reverse,query,hosting"
                    r = await self.client.get(url, timeout=8)
                    reqs_inner = 1
                    if r.status_code == 200:
                        d = r.json()
                        if d.get("status") == "success":
                            return ip, d
                except Exception:
                    pass
                return ip, None

        max_ips = self.config.get("max_ips", 4)
        tasks   = [lookup(ip) for ip in ips[:max_ips]]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        reqs   += len(tasks)

        for ip, info in results:
            if not info:
                continue
            country  = info.get("country","?")
            city     = info.get("city","?")
            region   = info.get("regionName","?")
            isp      = info.get("isp","?")
            org      = info.get("org","?")
            asn      = info.get("as","?")
            reverse  = info.get("reverse","")
            hosting  = info.get("hosting", False)

            evidence = (f"IP: {ip} | Location: {city}, {region}, {country} | "
                        f"ISP: {isp} | Org: {org} | ASN: {asn} | "
                        f"Hosting/Datacenter: {'Yes' if hosting else 'No'}")
            if reverse:
                evidence += f" | Reverse DNS: {reverse}"

            findings.append(Finding(
                source="ip_intel", category=FindingCategory.NETWORK,
                entity_type=EntityType.IP_ADDRESS, value=ip,
                confidence=Confidence.CONFIRMED, evidence=evidence,
                pivot_from=domain, metadata={
                    "ip": ip, "country": country, "country_code": info.get("countryCode"),
                    "city": city, "region": region, "isp": isp, "org": org,
                    "asn": asn, "reverse_dns": reverse, "is_hosting": hosting,
                }))

            if asn and asn != "?":
                findings.append(Finding(
                    source="ip_intel", category=FindingCategory.NETWORK,
                    entity_type=EntityType.ASN, value=asn,
                    confidence=Confidence.CONFIRMED,
                    evidence=f"ASN for {domain} ({ip}): {asn} — Org: {org}",
                    pivot_from=domain, metadata={"asn": asn, "org": org, "ip": ip}))

            if isp and isp != "?":
                findings.append(Finding(
                    source="ip_intel", category=FindingCategory.HOSTING,
                    entity_type=EntityType.HOSTING, value=isp,
                    confidence=Confidence.HIGH,
                    evidence=f"Hosting/ISP for {domain}: {isp} (Datacenter: {'Yes' if hosting else 'No'})",
                    pivot_from=domain, metadata={"isp": isp, "org": org, "hosting": hosting}))

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
