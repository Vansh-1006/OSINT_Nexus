
"""DNS Record Enumeration — A, AAAA, MX, NS, TXT, CNAME, SOA, DMARC."""
from __future__ import annotations
import time
import dns.asyncresolver, dns.resolver, dns.exception
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class DnsProvider(BaseProvider):
    name        = "dns"
    description = "DNS record enumeration — A, AAAA, MX, NS, TXT, SPF, DMARC"
    applies_to  = ["domain", "email"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start  = time.monotonic()
        domain = target.normalized.split("@")[-1] if target.type.value == "email" else target.normalized
        findings: list[Finding] = []
        reqs = 0
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = 5; resolver.lifetime = 10

        for rtype in ["A","AAAA","MX","NS","TXT","CNAME","SOA"]:
            f, r = await self._query(resolver, domain, rtype)
            findings.extend(f); reqs += r

        f, r = await self._query(resolver, f"_dmarc.{domain}", "TXT")
        findings.extend(f); reqs += r

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)

    async def _query(self, res, domain, rtype):
        findings = []
        try:
            answers = await res.resolve(domain, rtype)
            for rd in answers:
                v = str(rd)
                etype = {"A":EntityType.IP_ADDRESS,"AAAA":EntityType.IP_ADDRESS,
                         "MX":EntityType.DOMAIN,"NS":EntityType.DOMAIN,
                         "CNAME":EntityType.DOMAIN}.get(rtype, EntityType.DNS_RECORD)
                ev = f"DNS {rtype} for {domain}: {v}"
                meta = {"record_type":rtype,"domain":domain,"value":v}
                if rtype == "TXT":
                    vl = v.lower()
                    if "v=spf1" in vl:
                        ev = f"SPF policy for {domain}: {v}"
                        meta["intelligence"] = "Email sender policy (SPF)"
                    elif "v=dmarc1" in vl:
                        ev = f"DMARC policy for {domain}: {v}"
                        meta["intelligence"] = "Email authentication policy (DMARC)"
                    elif "google-site-verification" in vl:
                        meta["intelligence"] = "Google Search Console verification"
                    elif "ms=" in vl:
                        meta["intelligence"] = "Microsoft domain verification"
                if rtype == "MX":
                    mxh = v.split(" ")[-1].lower()
                    if "google" in mxh:        meta["email_provider"] = "Google Workspace"
                    elif "outlook" in mxh:     meta["email_provider"] = "Microsoft 365"
                    elif "protonmail" in mxh:  meta["email_provider"] = "ProtonMail"
                    elif "zoho" in mxh:        meta["email_provider"] = "Zoho Mail"
                    elif "mailgun" in mxh:     meta["email_provider"] = "Mailgun"
                    elif "sendgrid" in mxh:    meta["email_provider"] = "SendGrid"
                findings.append(Finding(source="dns", category=FindingCategory.DNS,
                    entity_type=etype, value=f"{rtype}: {v}", confidence=Confidence.CONFIRMED,
                    evidence=ev, pivot_from=domain, metadata=meta))
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.NoNameservers, dns.exception.Timeout):
            pass
        except Exception:
            pass
        return findings, 1
