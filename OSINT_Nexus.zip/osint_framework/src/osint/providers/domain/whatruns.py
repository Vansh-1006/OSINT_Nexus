
"""
WhatRuns Technology Intelligence Provider
==========================================
WhatRuns is a browser extension that identifies technologies running on websites.
This provider uses the same backend API the extension communicates with.

Unlike BuiltWith (paid API), WhatRuns requires NO API KEY — it queries the same
endpoint that the Chrome/Firefox extension uses when a user visits a page.

API endpoint  : POST https://www.whatruns.com/api/v1/get_site_apps
Authentication: None (public extension backend)
Rate limiting : Moderate — 1 request per domain per provider run is sufficient

Response includes:
  - Technology name
  - Category (CMS, Analytics, Framework, etc.)
  - Version (when detectable)
  - Confidence rating from WhatRuns' own detection engine

This complements our own web_fingerprint provider and BuiltWith:
  web_fingerprint  → pattern-matching against HTTP response (our own engine)
  whatruns         → WhatRuns' server-side detection engine (no key needed)
  builtwith        → BuiltWith's database (paid/free API key needed)
  urlscan          → Wappalyzer data embedded in URLScan results (free key)

Together these four sources give comprehensive, cross-validated tech detection.
"""
from __future__ import annotations
import json, time
from typing import Any
import httpx
from osint.models import (
    Confidence, EntityType, Finding, FindingCategory,
    InvestigationTarget, ProviderResult, ProviderStatus,
)
from osint.providers.base import BaseProvider


class WhatRunsProvider(BaseProvider):
    name         = "whatruns"
    description  = "WhatRuns extension API — technology detection, no key required"
    requires_key = False
    applies_to   = ["domain"]

    _API_URL = "https://www.whatruns.com/api/v1/get_site_apps"

    # WhatRuns extension ID headers — the server expects these to route requests
    _EXTRA_HEADERS = {
        "Origin":       "chrome-extension://cmkdbmfndkfgebliehgdembb",
        "Content-Type": "application/json;charset=UTF-8",
        "Accept":       "application/json, text/plain, */*",
        "Referer":      "https://www.whatruns.com/",
    }

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("WhatRuns only applies to domain targets")

        start  = time.monotonic()
        domain = target.normalized

        # Ensure we have a well-formed URL to send
        site_url = f"https://{domain}/"

        payload = {
            "hostname":    domain,
            "url":         site_url,
            "rawhostname": domain,
        }

        try:
            resp = await self.client.post(
                self._API_URL,
                content = json.dumps(payload),
                headers = {**self.client.headers, **self._EXTRA_HEADERS},
                timeout = self.timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as e:
            return self._fail(f"Connection error: {e}")
        except Exception as e:
            return self._fail(str(e))

        if resp.status_code == 429:
            return ProviderResult(
                provider=self.name, status=ProviderStatus.RATE_LIMITED,
                error="WhatRuns rate limited — try again shortly",
                duration=self._timed(start), requests_made=1)

        if resp.status_code == 403:
            return self._fail(
                "WhatRuns returned 403 — server may have changed extension headers")

        if resp.status_code not in (200, 201):
            return self._fail(f"Unexpected HTTP {resp.status_code}")

        try:
            data = resp.json()
        except Exception:
            return self._fail("Invalid JSON from WhatRuns API")

        findings = self._parse(data, domain)

        return ProviderResult(
            provider      = self.name,
            status        = ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings      = findings,
            duration      = self._timed(start),
            requests_made = 1,
        )

    def _parse(self, data: dict[str, Any], domain: str) -> list[Finding]:
        """
        Parse WhatRuns API response.

        Expected shape:
        {
          "apps": [
            {
              "name":       "WordPress",
              "id":         "WORDPRESS",
              "categories": ["CMS"],
              "type":       "app",
              "version":    "6.4.2",
              "rating":     5
            },
            ...
          ],
          "n": 12
        }
        """
        findings  : list[Finding] = []
        seen_names: set[str]      = set()

        apps = data.get("apps") or data.get("Apps") or []
        if not isinstance(apps, list):
            return findings

        for app in apps:
            name = (app.get("name") or app.get("Name") or "").strip()
            if not name or name.lower() in seen_names:
                continue
            seen_names.add(name.lower())

            # Version — WhatRuns sometimes includes it
            version   = (app.get("version") or app.get("Version") or "").strip()
            categories= app.get("categories") or app.get("Categories") or []
            if isinstance(categories, str):
                categories = [categories]
            rating    = app.get("rating") or app.get("Rating") or 0

            # Map WhatRuns rating (0-5) to our confidence levels
            if rating >= 4:
                confidence = Confidence.CONFIRMED
            elif rating >= 3:
                confidence = Confidence.HIGH
            elif rating >= 2:
                confidence = Confidence.MEDIUM
            else:
                confidence = Confidence.LOW

            # If no rating provided but WhatRuns returned the result, it's HIGH
            if not rating:
                confidence = Confidence.HIGH

            cat_str  = ", ".join(categories) if categories else "Unknown"
            ver_str  = f" v{version}" if version else ""
            value    = f"{name}{ver_str}"

            evidence = (
                f"WhatRuns detected: {name}{ver_str} | "
                f"Category: {cat_str} | "
                f"WhatRuns confidence rating: {rating}/5"
            )

            findings.append(Finding(
                source      = self.name,
                category    = FindingCategory.TECHNOLOGY,
                entity_type = EntityType.TECHNOLOGY,
                value       = value,
                confidence  = confidence,
                evidence    = evidence,
                pivot_from  = domain,
                metadata    = {
                    "tech_name":  name,
                    "version":    version or None,
                    "category":   cat_str,
                    "categories": categories,
                    "rating":     rating,
                    "source":     "whatruns",
                },
            ))

        return findings

    # ── Expose parser for unit testing without HTTP ───────────────────────
    @classmethod
    def parse_response(cls, data: dict, domain: str) -> list[Finding]:
        instance = cls.__new__(cls)
        return instance._parse(data, domain)
