
"""
BuiltWith Technology Intelligence Provider
==========================================
Uses the BuiltWith REST API to identify technologies on a domain.

Two tiers supported:
  Free  : https://api.builtwith.com/free1/api.json  (register free at builtwith.com)
  Paid  : https://api.builtwith.com/v21/api.json    (full dataset, paid plan)

The free tier returns a subset of technologies but is sufficient for most OSINT work.

Setup:
  1. Register free at https://builtwith.com/api
  2. export BUILTWITH_API_KEY=your_key_here
     OR set it in config.yaml under providers.builtwith.api_key
"""
from __future__ import annotations
import time
from typing import Any, Optional

import httpx

from osint.models import (
    Confidence, EntityType, Finding, FindingCategory,
    InvestigationTarget, ProviderResult, ProviderStatus,
)
from osint.providers.base import BaseProvider


class BuiltWithProvider(BaseProvider):
    name         = "builtwith"
    description  = "BuiltWith API — technology profiling with historical data (API key required)"
    requires_key = True
    applies_to   = ["domain"]

    # API tier endpoints
    _FREE_URL = "https://api.builtwith.com/free1/api.json"
    _FULL_URL = "https://api.builtwith.com/v21/api.json"

    def __init__(self, config: dict):
        super().__init__(config)
        self._api_key: str = config.get("api_key", "")
        # Automatically select full vs free endpoint based on key prefix
        # BuiltWith free keys typically differ from paid keys; user can override
        self._endpoint = config.get("endpoint", self._FREE_URL)

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("BuiltWith only applies to domain targets")

        if not self._api_key:
            return self._nokey(
                "BuiltWith API key required. "
                "Register free at https://builtwith.com/api "
                "then: export BUILTWITH_API_KEY=your_key"
            )

        start    = time.monotonic()
        domain   = target.normalized
        findings : list[Finding] = []

        try:
            resp = await self.client.get(
                self._endpoint,
                params={"KEY": self._api_key, "LOOKUP": domain},
                timeout=self.timeout,
            )
        except (httpx.TimeoutException, httpx.ConnectError) as e:
            return self._fail(f"Connection error: {e}")
        except Exception as e:
            return self._fail(str(e))

        if resp.status_code == 401:
            return self._nokey("Invalid BuiltWith API key")

        if resp.status_code == 403:
            return self._fail("BuiltWith API access denied — check key permissions")

        if resp.status_code == 429:
            return ProviderResult(
                provider=self.name,
                status=ProviderStatus.RATE_LIMITED,
                error="BuiltWith rate limit reached",
                duration=self._timed(start),
                requests_made=1,
            )

        if resp.status_code != 200:
            return self._fail(f"Unexpected HTTP {resp.status_code}")

        try:
            data = resp.json()
        except Exception:
            return self._fail("Invalid JSON response from BuiltWith")

        findings = self._parse(data, domain)

        return ProviderResult(
            provider      = self.name,
            status        = ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings      = findings,
            duration      = self._timed(start),
            requests_made = 1,
        )

    def _parse(self, data: dict, domain: str) -> list[Finding]:
        """
        Parse BuiltWith API response (both free and full tier share this structure).

        Free API response shape:
          { "Results": [{ "Result": { "Paths": [{ "Technologies": [...] }] } }] }

        Full API (v21) also nests under "Results[0].Result.Paths".
        """
        findings  : list[Finding] = []
        seen_names: set[str]      = set()

        results = data.get("Results", [])
        if not results:
            return findings

        # Walk Results → Result → Paths → Technologies
        for result_entry in results:
            result = result_entry.get("Result", {})
            paths  = result.get("Paths", [])

            for path_entry in paths:
                technologies = path_entry.get("Technologies", [])

                for tech in technologies:
                    name     = (tech.get("Name") or "").strip()
                    if not name or name.lower() in seen_names:
                        continue
                    seen_names.add(name.lower())

                    tag      = (tech.get("Tag") or "").strip()
                    desc     = (tech.get("Description") or "")[:200]
                    link     = tech.get("Link") or ""
                    cats     = tech.get("Categories") or []
                    is_prem  = tech.get("IsPremium", "No")

                    # Determine confidence: BuiltWith data is highly reliable
                    confidence = Confidence.CONFIRMED

                    category_str = ", ".join(cats) if cats else tag
                    evidence = (
                        f"BuiltWith detected: {name} | "
                        f"Category: {category_str} | "
                        f"Description: {desc[:120]}"
                    )

                    findings.append(Finding(
                        source      = self.name,
                        category    = FindingCategory.TECHNOLOGY,
                        entity_type = EntityType.TECHNOLOGY,
                        value       = name,
                        url         = link or None,
                        confidence  = confidence,
                        evidence    = evidence,
                        pivot_from  = domain,
                        metadata    = {
                            "tech_name":  name,
                            "category":   category_str,
                            "tag":        tag,
                            "categories": cats,
                            "description": desc,
                            "source":     "builtwith",
                            "is_premium": is_prem,
                        },
                    ))

        return findings

    # ── Response parser unit-testable separately ──────────────────────────
    @classmethod
    def parse_response(cls, data: dict, domain: str) -> list[Finding]:
        """Expose parser for unit testing without needing HTTP."""
        instance = cls.__new__(cls)
        return instance._parse(data, domain)
