
"""Web Content Intelligence — emails, phones, social links, meta info from pages."""
from __future__ import annotations
import re, time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider
from osint.utils import extract_emails, extract_phones

_SOCIAL = {
    "Twitter/X":  re.compile(r'(?:twitter|x)\.com/([A-Za-z0-9_]{1,50})', re.I),
    "LinkedIn":   re.compile(r'linkedin\.com/(?:in|company)/([A-Za-z0-9\-_%]{1,80})', re.I),
    "GitHub":     re.compile(r'github\.com/([A-Za-z0-9\-]{1,39})', re.I),
    "Facebook":   re.compile(r'facebook\.com/([A-Za-z0-9.\-]{1,60})', re.I),
    "Instagram":  re.compile(r'instagram\.com/([A-Za-z0-9_.]{1,30})', re.I),
    "YouTube":    re.compile(r'youtube\.com/(?:@|c/|channel/|user/)([A-Za-z0-9_\-]{1,80})', re.I),
    "TikTok":     re.compile(r'tiktok\.com/@([A-Za-z0-9_.]{1,30})', re.I),
    "Reddit":     re.compile(r'reddit\.com/(?:u|user)/([A-Za-z0-9_\-]{1,20})', re.I),
    "Telegram":   re.compile(r't\.me/([A-Za-z0-9_]{5,32})', re.I),
    "Pinterest":  re.compile(r'pinterest\.com/([A-Za-z0-9_]{1,30})', re.I),
    "Medium":     re.compile(r'medium\.com/@([A-Za-z0-9_]{1,50})', re.I),
}
# Ordered by value — most useful pages first
_PAGES = ["/", "/contact", "/about", "/about-us", "/contact-us",
          "/team", "/our-team", "/privacy", "/terms",
          "/.well-known/security.txt", "/humans.txt", "/blog", "/press"]
_META_RE = re.compile(
    r'<meta[^>]+name=["\']([^"\']+)["\'][^>]+content=["\']([^"\']{3,300})["\']',
    re.I | re.S,
)
_TITLE_RE = re.compile(r'<title[^>]*>([^<]{3,150})</title>', re.I)

class WebContentProvider(BaseProvider):
    name        = "web_content"
    description = "Extract emails, phones, social profiles, meta info from web pages"
    applies_to  = ["domain"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("Only applies to domain targets")
        start    = time.monotonic()
        domain   = target.normalized
        findings : list[Finding] = []
        reqs     = 0
        all_text = ""

        max_pages = self.config.get("max_pages", 8)
        for page in _PAGES[:max_pages]:
            for scheme in ["https", "http"]:
                try:
                    r = await self.client.get(f"{scheme}://{domain}{page}", timeout=10)
                    reqs += 1
                    if r.status_code == 200:
                        all_text += " " + r.text
                    break
                except Exception:
                    pass

        if not all_text.strip():
            return ProviderResult(provider=self.name, status=ProviderStatus.NO_RESULTS,
                                  duration=self._timed(start), requests_made=reqs)

        # Emails
        # Generic/placeholder email domains that are never real
        bad_keywords = {"example","test","schema","w3","noreply","no-reply","sentry",
                        "yourdomain","your-domain","domain.com","email.com",
                        "user@","addr@","info@example","sample","placeholder",
                        ".png",".jpg",".svg",".gif",".css",".js",".min."}
        bad_tlds = {".example",".test",".invalid",".localhost"}
        seen_e: set[str] = set()
        for em in extract_emails(all_text):
            e = em.lower().strip()
            # Skip obvious placeholders and false positives
            if any(b in e for b in bad_keywords):
                continue
            if any(e.endswith(t) for t in bad_tlds):
                continue
            # Skip if local part is clearly generic
            local = e.split("@")[0]
            if local in {"email","mail","user","admin","info","contact","support",
                         "hello","you","name","test","example","someone","address"}:
                continue
            if e in seen_e:
                continue
            seen_e.add(e)
            findings.append(Finding(
                source="web_content", category=FindingCategory.EMAIL,
                entity_type=EntityType.EMAIL, value=e,
                url=f"https://{domain}", confidence=Confidence.HIGH,
                evidence=f"Email found in public page content of {domain}",
                pivot_from=domain))

        # Phone numbers
        seen_p: set[str] = set()
        for ph in extract_phones(all_text):
            ph = re.sub(r'\s+', ' ', ph.strip())
            if len(re.sub(r'[^0-9]', '', ph)) < 7 or ph in seen_p:
                continue
            seen_p.add(ph)
            findings.append(Finding(
                source="web_content", category=FindingCategory.CONTACT,
                entity_type=EntityType.PHONE, value=ph,
                url=f"https://{domain}", confidence=Confidence.MEDIUM,
                evidence=f"Phone number in public page content of {domain}",
                pivot_from=domain))

        # Social links
        seen_s: set[str] = set()
        for platform, pat in _SOCIAL.items():
            for m in pat.finditer(all_text):
                handle = m.group(1).rstrip("/")
                key    = f"{platform}:{handle.lower()}"
                if key in seen_s:
                    continue
                seen_s.add(key)
                raw = m.group(0)
                full = raw if raw.startswith("http") else "https://" + raw
                findings.append(Finding(
                    source="web_content", category=FindingCategory.SOCIAL,
                    entity_type=EntityType.PROFILE, value=f"{platform}: {handle}",
                    url=full, confidence=Confidence.HIGH,
                    evidence=f"Social link found on {domain} website",
                    pivot_from=domain,
                    metadata={"platform": platform, "handle": handle}))

        # Page title
        tm = _TITLE_RE.search(all_text)
        if tm:
            findings.append(Finding(
                source="web_content", category=FindingCategory.MENTION,
                entity_type=EntityType.MENTION, value=tm.group(1).strip(),
                url=f"https://{domain}", confidence=Confidence.CONFIRMED,
                evidence=f"Page title from {domain}",
                pivot_from=domain, metadata={"type": "page_title"}))

        # Meta tags (description, author, generator, copyright)
        for mm in _META_RE.finditer(all_text):
            name    = mm.group(1).lower().strip()
            content = mm.group(2).strip()
            if name in {"description", "author", "generator", "copyright", "owner"}:
                findings.append(Finding(
                    source="web_content", category=FindingCategory.MENTION,
                    entity_type=EntityType.MENTION,
                    value=f"[{name}] {content[:200]}",
                    url=f"https://{domain}", confidence=Confidence.HIGH,
                    evidence=f"Meta {name} tag from {domain}: {content[:200]}",
                    pivot_from=domain, metadata={"type": f"meta_{name}", "content": content[:300]}))

        return ProviderResult(
            provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
