
"""
Web Technology Fingerprinting Provider — v2 with deep version extraction
========================================================================
Version extraction sources (in order of reliability):
  1. HTTP response headers     → Server:, X-Powered-By:, X-AspNet-Version:
  2. HTML meta generator tag   → <meta name="generator" content="WordPress 6.4.2">
  3. HTML attribute patterns   → ng-version="17.0.5"
  4. Script/link src URLs      → jquery-3.7.0.min.js, ?ver=5.3.2
  5. Inline JS comments        → /*! jQuery v3.7.0 */ /*! Bootstrap v5.3.2 */
  6. Inline JS variables       → React.version="18.2.0", Vue.version="2.7.14"
  7. Probe paths               → /readme.html (WordPress), /package.json
  8. Cookie names              → confirm presence (version rarely in cookies)

If a version cannot be extracted, the finding still reports the technology
with evidence explaining what was matched and why the version is unavailable.
"""
from __future__ import annotations
import asyncio, re, time
from typing import Optional
import httpx
from bs4 import BeautifulSoup, Comment
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

# ── Technology signatures ─────────────────────────────────────────────────
import re as _re
def _r(p, f=_re.I): return _re.compile(p, f)

SIGS = {
  "WordPress":   {"cat":"CMS","url":"wordpress.org","headers":{"Link":(_r(r'</wp-json'),None)},
    "html":[(_r(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']WordPress\s+([0-9.]+)'),1,98),
            (_r(r'/wp-content/(?:themes|plugins|uploads)/'),None,90),(_r(r'wp-emoji'),None,82)],
    "cookies":[("wordpress_",92),("wp-settings-",90)],"paths":[("/wp-login.php",200,98),("/wp-json/wp/v2/",200,97)]},
  "Drupal":      {"cat":"CMS","url":"drupal.org","headers":{"X-Generator":(_r(r'Drupal\s+([0-9]+)'),1),"X-Drupal-Cache":(_r(r'.+'),None)},
    "html":[(_r(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']Drupal\s+([0-9]+)'),1,98),
            (_r(r'/sites/(?:default|all)/(?:themes|modules)/'),None,88),(_r(r'Drupal\.settings'),None,90)],
    "cookies":[("SSESS",88)],"paths":[("/core/CHANGELOG.txt",200,88)]},
  "Joomla":      {"cat":"CMS","url":"joomla.org","headers":{},
    "html":[(_r(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']Joomla!\s+([0-9.]+)'),1,98),
            (_r(r'/components/com_'),None,85),(_r(r'Joomla\.JText'),None,90)],
    "cookies":[("joomla_user_state",90)],"paths":[]},
  "Magento":     {"cat":"CMS","url":"magento.com","headers":{},
    "html":[(_r(r'Mage\.Cookies'),None,92),(_r(r'skin/frontend/'),None,88)],
    "cookies":[("frontend",60)],"paths":[]},
  "Shopify":     {"cat":"CMS","url":"shopify.com","headers":{"X-ShopId":(_r(r'.+'),None),"Server":(_r(r'Shopify'),None)},
    "html":[(_r(r'cdn\.shopify\.com/'),None,97),(_r(r'window\.Shopify'),None,97)],
    "cookies":[("_shopify_",97)],"paths":[]},
  "Wix":         {"cat":"CMS","url":"wix.com","headers":{"X-Wix-Request-Id":(_r(r'.+'),None)},
    "html":[(_r(r'static\.wix\.com'),None,97),(_r(r'wix-warmup-data'),None,95)],
    "cookies":[("wixCIDX",97)],"paths":[]},
  "Squarespace": {"cat":"CMS","url":"squarespace.com","headers":{"Server":(_r(r'Squarespace'),None)},
    "html":[(_r(r'static\.squarespace\.com'),None,97),(_r(r'Squarespace\.afterBodyLoad'),None,97)],
    "cookies":[("ss_cid",92)],"paths":[]},
  "Ghost":       {"cat":"CMS","url":"ghost.org","headers":{"X-Ghost-Cache-Status":(_r(r'.+'),None)},
    "html":[(_r(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']Ghost\s+([0-9.]+)'),1,99)],
    "cookies":[],"paths":[("/ghost/",302,88)]},
  "PrestaShop":  {"cat":"CMS","url":"prestashop.com","headers":{},
    "html":[(_r(r'/modules/ps_'),None,90),(_r(r'PrestaShop'),None,82)],
    "cookies":[("PrestaShop-",92)],"paths":[]},
  "TYPO3":       {"cat":"CMS","url":"typo3.org","headers":{"X-TYPO3-Parsetime":(_r(r'.+'),None)},
    "html":[(_r(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']TYPO3\s+([0-9.]+)'),1,99),(_r(r'typo3temp/'),None,90)],
    "cookies":[("fe_typo_user",92)],"paths":[]},
  "Webflow":     {"cat":"CMS","url":"webflow.com","headers":{"X-Powered-By":(_r(r'Webflow'),None)},
    "html":[(_r(r'data-wf-site'),None,97),(_r(r'webflow\.com/css'),None,95)],
    "cookies":[],"paths":[]},
  "React":       {"cat":"Framework","url":"react.dev","headers":{},
    "html":[(_r(r'data-reactroot'),None,90),(_r(r'__REACT_ERROR_OVERLAY'),None,88),(_r(r'react-dom'),None,78)],
    "cookies":[],"paths":[]},
  "Next.js":     {"cat":"Framework","url":"nextjs.org","headers":{"X-Powered-By":(_r(r'Next\.js'),None),"X-Nextjs-Cache":(_r(r'.+'),None)},
    "html":[(_r(r'__NEXT_DATA__'),None,99),(_r(r'/_next/static/'),None,97)],
    "cookies":[],"paths":[]},
  "Vue.js":      {"cat":"Framework","url":"vuejs.org","headers":{},
    "html":[(_r(r'__vue__'),None,90),(_r(r'data-v-[0-9a-f]{8}'),None,88),(_r(r'vue(?:\.min)?\.js'),None,80)],
    "cookies":[],"paths":[]},
  "Nuxt.js":     {"cat":"Framework","url":"nuxt.com","headers":{"X-Nuxt-Render-Time":(_r(r'.+'),None)},
    "html":[(_r(r'__NUXT__'),None,99),(_r(r'/_nuxt/'),None,97)],
    "cookies":[],"paths":[]},
  "Angular":     {"cat":"Framework","url":"angular.io","headers":{},
    "html":[(_r(r'ng-version=["\']([0-9.]+)["\']'),1,99),(_r(r'_nghost-|_ngcontent-'),None,90)],
    "cookies":[],"paths":[]},
  "Svelte":      {"cat":"Framework","url":"svelte.dev","headers":{},
    "html":[(_r(r'class="svelte-'),None,92),(_r(r'__svelte'),None,90)],
    "cookies":[],"paths":[]},
  "Gatsby":      {"cat":"Framework","url":"gatsbyjs.com","headers":{},
    "html":[(_r(r'___gatsby'),None,99),(_r(r'gatsby-focus-wrapper'),None,97)],
    "cookies":[],"paths":[]},
  "Astro":       {"cat":"Framework","url":"astro.build","headers":{},
    "html":[(_r(r'astro-island'),None,95)],
    "cookies":[],"paths":[]},
  "Django":      {"cat":"Framework","url":"djangoproject.com","headers":{},
    "html":[(_r(r'csrfmiddlewaretoken'),None,80)],
    "cookies":[("csrftoken",75)],"paths":[]},
  "Laravel":     {"cat":"Framework","url":"laravel.com","headers":{},
    "html":[(_r(r'laravel_session'),None,88)],
    "cookies":[("laravel_session",95),("XSRF-TOKEN",72)],"paths":[]},
  "Ruby on Rails":{"cat":"Framework","url":"rubyonrails.org","headers":{"X-Powered-By":(_r(r'Phusion Passenger\s+([0-9.]+)'),1),"X-Runtime":(_r(r'[0-9.]+'),None)},
    "html":[],"cookies":[("_rails",82)],"paths":[]},
  "ASP.NET":     {"cat":"Framework","url":"asp.net","headers":{"X-Powered-By":(_r(r'ASP\.NET'),None),"X-AspNet-Version":(_r(r'([0-9.]+)'),1)},
    "html":[(_r(r'__VIEWSTATE'),None,92),(_r(r'__EVENTTARGET'),None,90)],
    "cookies":[("ASP.NET_SessionId",97),("ASPXAUTH",92)],"paths":[]},
  "Express.js":  {"cat":"Framework","url":"expressjs.com","headers":{"X-Powered-By":(_r(r'Express'),None)},
    "html":[],"cookies":[("connect.sid",85)],"paths":[]},
  "Flask":       {"cat":"Framework","url":"flask.palletsprojects.com","headers":{"Server":(_r(r'Werkzeug/([0-9.]+)'),1)},
    "html":[],"cookies":[],"paths":[]},
  "Spring":      {"cat":"Framework","url":"spring.io","headers":{},
    "html":[(_r(r'Whitelabel Error Page'),None,92)],"cookies":[("JSESSIONID",70)],"paths":[]},
  "FastAPI":     {"cat":"Framework","url":"fastapi.tiangolo.com","headers":{"Server":(_r(r'uvicorn'),None)},
    "html":[],"cookies":[],"paths":[("/openapi.json",200,85)]},
  "Symfony":     {"cat":"Framework","url":"symfony.com","headers":{"X-Debug-Token":(_r(r'.+'),None)},
    "html":[],"cookies":[("sf_redirect",85)],"paths":[]},
  "Apache":      {"cat":"Server","url":"httpd.apache.org","headers":{"Server":(_r(r'Apache(?:/([0-9.]+))?'),1)},
    "html":[],"cookies":[],"paths":[]},
  "Nginx":       {"cat":"Server","url":"nginx.org","headers":{"Server":(_r(r'nginx(?:/([0-9.]+))?'),1)},
    "html":[(_r(r'Welcome to nginx'),None,97)],"cookies":[],"paths":[]},
  "Microsoft IIS":{"cat":"Server","url":"iis.net","headers":{"Server":(_r(r'Microsoft-IIS/([0-9.]+)'),1)},
    "html":[(_r(r'IIS Windows Server'),None,97)],"cookies":[],"paths":[]},
  "LiteSpeed":   {"cat":"Server","url":"litespeedtech.com","headers":{"Server":(_r(r'LiteSpeed'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Caddy":       {"cat":"Server","url":"caddyserver.com","headers":{"Server":(_r(r'Caddy'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Gunicorn":    {"cat":"Server","url":"gunicorn.org","headers":{"Server":(_r(r'gunicorn(?:/([0-9.]+))?'),1)},
    "html":[],"cookies":[],"paths":[]},
  "OpenResty":   {"cat":"Server","url":"openresty.org","headers":{"Server":(_r(r'openresty(?:/([0-9.]+))?'),1)},
    "html":[],"cookies":[],"paths":[]},
  "PHP":         {"cat":"Language","url":"php.net","headers":{"X-Powered-By":(_r(r'PHP/([0-9.]+)'),1)},
    "html":[],"cookies":[("PHPSESSID",88)],"paths":[]},
  "Python":      {"cat":"Language","url":"python.org","headers":{"X-Powered-By":(_r(r'Python/([0-9.]+)'),1),"Server":(_r(r'Python/([0-9.]+)'),1)},
    "html":[],"cookies":[],"paths":[]},
  "jQuery":      {"cat":"Library","url":"jquery.com","headers":{},
    "html":[(_r(r'jquery[.\-]([0-9]+\.[0-9]+\.[0-9]+)(?:\.min)?\.js'),1,95),
            (_r(r'jquery\.min\.js'),None,85)],
    "cookies":[],"paths":[]},
  "Bootstrap":   {"cat":"Library","url":"getbootstrap.com","headers":{},
    "html":[(_r(r'bootstrap[.\-]([0-9]+\.[0-9]+\.[0-9]+)(?:\.min)?\.(?:js|css)'),1,92),
            (_r(r'class="(?:btn btn-|navbar |container(?:-fluid)? )'),None,70)],
    "cookies":[],"paths":[]},
  "Tailwind CSS":{"cat":"Library","url":"tailwindcss.com","headers":{},
    "html":[(_r(r'cdn\.tailwindcss\.com'),None,97),(_r(r'tailwind'),None,72)],
    "cookies":[],"paths":[]},
  "Cloudflare":  {"cat":"CDN","url":"cloudflare.com","headers":{"CF-Ray":(_r(r'.+'),None),"Server":(_r(r'cloudflare'),None)},
    "html":[],"cookies":[("__cflb",97),("cf_clearance",97),("__cf_bm",95)],"paths":[]},
  "AWS CloudFront":{"cat":"CDN","url":"aws.amazon.com/cloudfront","headers":{"X-Amz-Cf-Id":(_r(r'.+'),None),"Via":(_r(r'CloudFront'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Vercel":      {"cat":"Hosting","url":"vercel.com","headers":{"X-Vercel-Id":(_r(r'.+'),None),"Server":(_r(r'Vercel'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Netlify":     {"cat":"Hosting","url":"netlify.com","headers":{"X-Nf-Request-Id":(_r(r'.+'),None),"Server":(_r(r'Netlify'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Fastly":      {"cat":"CDN","url":"fastly.com","headers":{"X-Fastly-Request-ID":(_r(r'.+'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Akamai":      {"cat":"CDN","url":"akamai.com","headers":{"X-Akamai-Transformed":(_r(r'.+'),None),"Server":(_r(r'AkamaiGHost'),None)},
    "html":[],"cookies":[],"paths":[]},
  "GitHub Pages":{"cat":"Hosting","url":"pages.github.com","headers":{"Server":(_r(r'GitHub\.com'),None),"X-GitHub-Request-Id":(_r(r'.+'),None)},
    "html":[],"cookies":[],"paths":[]},
  "Google Analytics":{"cat":"Analytics","url":"analytics.google.com","headers":{},
    "html":[(_r(r'gtag\([\'\"]config[\'\"].*?[\'\"]G-([A-Z0-9]+)[\'\"]'),1,97),
            (_r(r'google-analytics\.com/analytics\.js'),None,95),(_r(r'UA-[0-9]+-[0-9]+'),None,90)],
    "cookies":[],"paths":[]},
  "Google Tag Manager":{"cat":"Analytics","url":"tagmanager.google.com","headers":{},
    "html":[(_r(r'googletagmanager\.com/gtm\.js'),None,97),(_r(r'GTM-[A-Z0-9]+'),None,97)],
    "cookies":[],"paths":[]},
  "Matomo":      {"cat":"Analytics","url":"matomo.org","headers":{},
    "html":[(_r(r'matomo\.js'),None,92),(_r(r'_paq\.push'),None,92)],
    "cookies":[],"paths":[]},
  "Hotjar":      {"cat":"Analytics","url":"hotjar.com","headers":{},
    "html":[(_r(r'hotjar\.com'),None,95),(_r(r'hjid:'),None,92)],
    "cookies":[],"paths":[]},
  "Facebook Pixel":{"cat":"Analytics","url":"facebook.com","headers":{},
    "html":[(_r(r'fbevents\.js'),None,97),(_r(r'fbq\([\'\"]init'),None,97)],
    "cookies":[],"paths":[]},
  "HubSpot":     {"cat":"Analytics","url":"hubspot.com","headers":{},
    "html":[(_r(r'js\.hs-scripts\.com'),None,97),(_r(r'_hsq\.push'),None,95)],
    "cookies":[("hubspotutk",97),("__hssc",92)],"paths":[]},
  "reCAPTCHA":   {"cat":"Security","url":"google.com/recaptcha","headers":{},
    "html":[(_r(r'google\.com/recaptcha'),None,97),(_r(r'grecaptcha'),None,95)],
    "cookies":[],"paths":[]},
  "hCaptcha":    {"cat":"Security","url":"hcaptcha.com","headers":{},
    "html":[(_r(r'hcaptcha\.com'),None,97)],"cookies":[],"paths":[]},
  "WooCommerce": {"cat":"Ecommerce","url":"woocommerce.com","headers":{},
    "html":[(_r(r'/wp-content/plugins/woocommerce/'),None,99),(_r(r'woocommerce'),None,88)],
    "cookies":[("woocommerce_",97)],"paths":[]},
  "Stripe":      {"cat":"Ecommerce","url":"stripe.com","headers":{},
    "html":[(_r(r'js\.stripe\.com'),None,97),(_r(r'Stripe\('),None,92)],
    "cookies":[],"paths":[]},
  "Intercom":    {"cat":"Support","url":"intercom.com","headers":{},
    "html":[(_r(r'widget\.intercom\.io'),None,97),(_r(r'Intercom\('),None,92)],
    "cookies":[],"paths":[]},
  "Zendesk":     {"cat":"Support","url":"zendesk.com","headers":{},
    "html":[(_r(r'zendesk\.com'),None,85),(_r(r'zESettings|zE\('),None,92)],
    "cookies":[],"paths":[]},
}

# ── Deep version extraction patterns ─────────────────────────────────────
# These are scanned across ALL src/href URLs, JS comments, and inline JS.
# Format: (compiled_regex, tech_name, source_description)

_VER_FROM_URL = [
    # CDN / filename patterns with semver
    (_r(r'jquery[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "jQuery",       "filename/URL"),
    (_r(r'bootstrap[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),        "Bootstrap",    "filename/URL"),
    (_r(r'vue[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),              "Vue.js",       "filename/URL"),
    (_r(r'/react@([0-9]+\.[0-9]+\.[0-9]+)/'),                  "React",        "CDN URL"),
    (_r(r'/react[@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),             "React",        "filename/URL"),
    (_r(r'angular[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),           "Angular",      "filename/URL"),
    (_r(r'lodash[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),            "Lodash",       "filename/URL"),
    (_r(r'moment[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),            "Moment.js",    "filename/URL"),
    (_r(r'gsap[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),              "GSAP",         "filename/URL"),
    (_r(r'swiper[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),            "Swiper",       "filename/URL"),
    (_r(r'three[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),             "Three.js",     "filename/URL"),
    (_r(r'd3[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),                "D3.js",        "filename/URL"),
    (_r(r'alpinejs[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "Alpine.js",    "filename/URL"),
    (_r(r'chart\.?js[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),        "Chart.js",     "filename/URL"),
    (_r(r'nuxt[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),              "Nuxt.js",      "filename/URL"),
    (_r(r'next[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),              "Next.js",      "filename/URL"),
    (_r(r'tailwindcss[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),       "Tailwind CSS", "filename/URL"),
    (_r(r'aos[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),               "AOS",          "filename/URL"),
    (_r(r'slick[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),             "Slick",        "filename/URL"),
    (_r(r'select2[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),           "Select2",      "filename/URL"),
    (_r(r'datatables[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),        "DataTables",   "filename/URL"),
    (_r(r'fontawesome[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),       "Font Awesome", "filename/URL"),
    (_r(r'font-awesome[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),      "Font Awesome", "filename/URL"),
    (_r(r'materialize[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),       "Materialize",  "filename/URL"),
    (_r(r'foundation[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),        "Foundation",   "filename/URL"),
    (_r(r'bulma[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),             "Bulma",        "filename/URL"),
    (_r(r'semantic[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "Semantic UI",  "filename/URL"),
    (_r(r'ember[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),             "Ember.js",     "filename/URL"),
    (_r(r'backbone[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "Backbone.js",  "filename/URL"),
    (_r(r'knockout[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "Knockout.js",  "filename/URL"),
    (_r(r'prototype[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),         "Prototype.js", "filename/URL"),
    (_r(r'mootools[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),          "MooTools",     "filename/URL"),
    (_r(r'underscore[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),        "Underscore.js","filename/URL"),
    (_r(r'rx[/@.\-]v?([0-9]+\.[0-9]+\.[0-9]+)'),                "RxJS",         "filename/URL"),
]

_WP_VER_PARAM = _r(r'\?ver=([0-9]+\.[0-9]+(?:\.[0-9]+)?)')

_VER_FROM_JS = [
    # JS comment banners (most libraries include these)
    (_r(r'/\*[!\s]*jQuery\s+v?([0-9]+\.[0-9]+\.[0-9]+)'),      "jQuery",       "JS comment banner"),
    (_r(r'jQuery\s+JavaScript\s+Library\s+v([0-9]+\.[0-9]+\.[0-9]+)'), "jQuery","JS comment"),
    (_r(r'jQuery\.fn\.jquery\s*[=:]\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'), "jQuery","JS variable"),
    (_r(r'/\*[!\s]*Bootstrap\s+v([0-9]+\.[0-9]+\.[0-9]+)'),    "Bootstrap",    "JS/CSS comment banner"),
    (_r(r'Bootstrap\s+v([0-9]+\.[0-9]+\.[0-9]+)'),             "Bootstrap",    "version comment"),
    (_r(r'/\*[!\s]*Vue\.js\s+v([0-9]+\.[0-9]+\.[0-9]+)'),      "Vue.js",       "JS comment banner"),
    (_r(r'Vue\.version\s*[=:]\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'),       "Vue.js","JS variable"),
    (_r(r'React\.version\s*[=:]\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'),     "React","JS variable"),
    (_r(r'React\s*=\s*\{[^}]{0,40}version:\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'), "React","JS object literal"),
    (_r(r'"react":\s*"[^"]*([0-9]+\.[0-9]+\.[0-9]+)'),         "React",        "package reference"),
    (_r(r'/\*[!\s]*GSAP\s+([0-9]+\.[0-9]+\.[0-9]+)'),          "GSAP",         "JS comment banner"),
    (_r(r'gsap\s+([0-9]+\.[0-9]+\.[0-9]+)'),                   "GSAP",         "version string"),
    (_r(r'_gsap_version\s*[=:]\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'),      "GSAP","JS variable"),
    (_r(r'/\*[!\s]*Lodash\s+v?([0-9]+\.[0-9]+\.[0-9]+)'),      "Lodash",       "JS comment banner"),
    (_r(r'lodash\s+([0-9]+\.[0-9]+\.[0-9]+)'),                 "Lodash",       "version string"),
    (_r(r'moment\.version\s*=\s*["\']([0-9]+\.[0-9]+\.[0-9]+)'),        "Moment.js","JS variable"),
    (_r(r'/\*[!\s]*Moment\.js\s+([0-9]+\.[0-9]+\.[0-9]+)'),   "Moment.js",    "JS comment banner"),
    (_r(r'THREE\.REVISION\s*=\s*["\']?([0-9]+)["\']?'),         "Three.js",     "JS revision variable"),
    (_r(r'Swiper\s+([0-9]+\.[0-9]+\.[0-9]+)'),                 "Swiper",       "version string"),
    (_r(r'D3\s+v([0-9]+\.[0-9]+\.[0-9]+)'),                    "D3.js",        "version string"),
    (_r(r'Font\s+Awesome\s+([0-9]+\.[0-9]+\.[0-9]+)'),         "Font Awesome", "version string"),
    (_r(r'chart\.js\s+v([0-9]+\.[0-9]+\.[0-9]+)'),             "Chart.js",     "version string"),
    (_r(r'Alpine\s+Version:\s*([0-9]+\.[0-9]+\.[0-9]+)'),      "Alpine.js",    "version string"),
    (_r(r'/\*[!\s]*Tailwind\s+CSS\s+v([0-9]+\.[0-9]+\.[0-9]+)'), "Tailwind CSS","CSS comment banner"),
]

_VER_FROM_META = [
    (_r(r'<meta[^>]+generator[^>]+WordPress\s+([0-9.]+)'),      "WordPress"),
    (_r(r'<meta[^>]+generator[^>]+Drupal\s+([0-9]+)'),          "Drupal"),
    (_r(r'<meta[^>]+generator[^>]+Joomla[! ]+([0-9.]+)'),       "Joomla"),
    (_r(r'<meta[^>]+generator[^>]+Ghost\s+([0-9.]+)'),          "Ghost"),
    (_r(r'<meta[^>]+generator[^>]+TYPO3\s+([0-9.]+)'),          "TYPO3"),
    (_r(r'ng-version=["\']([0-9.]+)["\']'),                     "Angular"),
]


class WebFingerprintProvider(BaseProvider):
    name        = "web_fingerprint"
    description = "Tech fingerprinting — 50+ techs with deep version extraction from headers, HTML, JS, CSS"
    applies_to  = ["domain"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "domain":
            return self._skip("Domain only")

        start   = time.monotonic()
        domain  = target.normalized
        results : list[dict] = []
        reqs    = 0
        body    = ""
        headers : dict = {}

        # ── 1. Fetch main page ─────────────────────────────────────────
        for scheme in ["https", "http"]:
            try:
                resp = await self.client.get(f"{scheme}://{domain}",
                                             timeout=self.timeout)
                reqs += 1
                body    = resp.text
                headers = {k.lower(): v for k, v in resp.headers.items()}
                cookies = {c.name: c.value for c in resp.cookies.jar}
                results += self._analyse_headers(headers, domain)
                results += self._analyse_html(body, domain)
                results += self._analyse_cookies(cookies, domain, results)
                break
            except Exception:
                pass

        # ── 2. robots.txt for CMS hints ────────────────────────────────
        try:
            rb = await self.client.get(f"https://{domain}/robots.txt", timeout=5)
            reqs += 1
            if rb.status_code == 200:
                if "wp-admin" in rb.text:
                    self._merge(results, "WordPress", "robots.txt", 85,
                                "wp-admin in robots.txt confirms WordPress")
        except Exception:
            pass

        # ── 3. Path probing with content validation ────────────────────
        probe_tasks: list[tuple] = []
        probed: set[str] = set()
        for tech_name, sig in SIGS.items():
            for (path, exp_status, conf) in sig.get("paths", []):
                if path not in probed:
                    probed.add(path)
                    probe_tasks.append((tech_name, path, exp_status, conf))

        _path_content_validators = {
            "/wp-login.php":   "wordpress",
            "/wp-json/wp/v2/": '"namespaces"',
            "/administrator/": "joomla",
            "/core/CHANGELOG.txt": "drupal",
            "/ghost/":         "ghost",
            "/openapi.json":   '"openapi"',
        }

        sem_probe = asyncio.Semaphore(self.config.get("probe_concurrency", 10))

        async def probe_one(tname, path, exp, conf):
            async with sem_probe:
                try:
                    r = await self.client.get(f"https://{domain}{path}", timeout=4)
                    if r.status_code == exp:
                        validator = _path_content_validators.get(path)
                        if validator and validator.lower() not in r.text.lower():
                            return
                        self._merge(results, tname, "path_probe", conf,
                                    f"Path {path} returned HTTP {exp} with expected content")
                except Exception:
                    pass

        await asyncio.gather(*[probe_one(*t) for t in probe_tasks],
                             return_exceptions=True)
        reqs += len(probe_tasks)

        # ── 4. WordPress readme.html version probe ─────────────────────
        if body and ("wp-content" in body or "wp-includes" in body):
            try:
                rb = await self.client.get(f"https://{domain}/readme.html", timeout=5)
                reqs += 1
                if rb.status_code == 200:
                    m = re.search(r'Version\s+([0-9]+\.[0-9]+(?:\.[0-9]+)?)', rb.text, re.I)
                    if m:
                        self._set_version(results, "WordPress", m.group(1),
                                          "readme.html version page")
            except Exception:
                pass

        # ── 5. Deep HTML version extraction ───────────────────────────
        if body:
            version_map = self._deep_extract_versions(body)
            for tech_name, (version, source_desc) in version_map.items():
                self._set_version(results, tech_name, version, source_desc)
                # If tech wasn't detected yet, add it now
                if not any(r["name"] == tech_name for r in results):
                    sig = SIGS.get(tech_name, {})
                    results.append({
                        "name":       tech_name,
                        "category":   sig.get("cat", "Library"),
                        "version":    version,
                        "confidence": 85,
                        "match_type": "version_pattern",
                        "evidence":   f"Detected via version string in {source_desc}: {version}",
                    })

        # ── 6. Build findings ──────────────────────────────────────────
        findings : list[Finding] = []
        seen_names: set[str]     = set()
        for r in results:
            name = r["name"].lower()
            if name in seen_names:
                continue
            seen_names.add(name)

            sig      = SIGS.get(r["name"], {})
            version  = r.get("version") or ""
            conf_val = r["confidence"]
            if conf_val >= 95:   c = Confidence.CONFIRMED
            elif conf_val >= 80: c = Confidence.HIGH
            elif conf_val >= 65: c = Confidence.MEDIUM
            else:                c = Confidence.LOW

            display = f"{r['name']} v{version}" if version else r["name"]

            # Explain clearly when version is unavailable
            if version:
                evidence = r.get("evidence", "")
            else:
                evidence = (r.get("evidence", "") +
                            " | Version: not disclosed (server may have version "
                            "disclosure disabled — this is a security hardening measure)")

            findings.append(Finding(
                source      = self.name,
                category    = FindingCategory.TECHNOLOGY,
                entity_type = EntityType.TECHNOLOGY,
                value       = display,
                url         = f"https://{sig.get('url','')}" if sig.get('url') else None,
                confidence  = c,
                evidence    = evidence.strip(" |"),
                pivot_from  = domain,
                metadata    = {
                    "tech_name":       r["name"],
                    "version":         version or None,
                    "category":        r.get("category", sig.get("cat", "?")),
                    "match_type":      r.get("match_type"),
                    "confidence_score":conf_val,
                    "version_source":  r.get("version_source"),
                },
            ))

        return ProviderResult(
            provider      = self.name,
            status        = ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings      = findings,
            duration      = self._timed(start),
            requests_made = reqs,
        )

    # ── Header analysis ───────────────────────────────────────────────────

    def _analyse_headers(self, headers: dict, domain: str) -> list[dict]:
        results = []
        for name, sig in SIGS.items():
            for hdr, (pat, vg) in sig.get("headers", {}).items():
                val = headers.get(hdr.lower(), "")
                if not val:
                    continue
                m = pat.search(val)
                if m:
                    ver = (m.group(vg) if vg and m.lastindex and m.lastindex >= vg
                           else None)
                    results.append({
                        "name":       name,
                        "category":   sig.get("cat", "?"),
                        "version":    ver,
                        "confidence": 92,
                        "match_type": "header",
                        "evidence":   f"HTTP header {hdr}: {val[:120]}",
                        "version_source": f"HTTP header {hdr}" if ver else None,
                    })
                    break
        return results

    # ── HTML pattern analysis ─────────────────────────────────────────────

    def _analyse_html(self, body: str, domain: str) -> list[dict]:
        results = []
        for name, sig in SIGS.items():
            for (pat, vg, base_conf) in sig.get("html", []):
                m = pat.search(body)
                if m:
                    ver = (m.group(vg) if vg and m.lastindex and m.lastindex >= vg
                           else None)
                    results.append({
                        "name":       name,
                        "category":   sig.get("cat", "?"),
                        "version":    ver,
                        "confidence": base_conf,
                        "match_type": "html_pattern",
                        "evidence":   f"HTML pattern matched: {m.group(0)[:100]}",
                        "version_source": "HTML pattern" if ver else None,
                    })
                    break
        return results

    # ── Cookie analysis ───────────────────────────────────────────────────

    def _analyse_cookies(self, cookies: dict, domain: str,
                         existing: list[dict]) -> list[dict]:
        results = []
        existing_names = {r["name"] for r in existing}
        for name, sig in SIGS.items():
            if name in existing_names:
                continue
            for (prefix, conf) in sig.get("cookies", []):
                for cname in cookies:
                    if cname.lower().startswith(prefix.lower()):
                        results.append({
                            "name":       name,
                            "category":   sig.get("cat", "?"),
                            "version":    None,
                            "confidence": conf,
                            "match_type": "cookie",
                            "evidence":   f"Cookie detected: {cname}",
                        })
                        break
        return results

    # ── Deep version extraction from HTML ─────────────────────────────────

    def _deep_extract_versions(self, body: str) -> dict[str, tuple[str, str]]:
        """
        Scan all script src URLs, link href URLs, inline JS, and HTML comments
        for technology version numbers.
        Returns: {tech_name: (version_string, source_description)}
        """
        versions: dict[str, tuple[str, str]] = {}

        try:
            soup = BeautifulSoup(body[:300_000], "lxml")

            # ── All resource URLs ──────────────────────────────────────
            all_urls: list[str] = []
            for tag in soup.find_all(["script", "link"]):
                url = tag.get("src") or tag.get("href") or ""
                if url:
                    all_urls.append(url)

            for url in all_urls:
                # Version in URL/filename (e.g., jquery-3.7.0.min.js)
                for pat, tech, desc in _VER_FROM_URL:
                    if tech not in versions:
                        m = pat.search(url)
                        if m:
                            versions[tech] = (m.group(1), f"resource URL ({desc})")

                # WordPress ?ver= query parameter
                if "wp-" in url.lower() or "wordpress" in url.lower():
                    m = _WP_VER_PARAM.search(url)
                    if m and "WordPress" not in versions:
                        versions["WordPress"] = (m.group(1), "?ver= parameter in WP resource URL")

            # ── Inline script content ──────────────────────────────────
            inline_js = "\n".join(
                s.string for s in soup.find_all("script")
                if not s.get("src") and s.string
            )
            if inline_js:
                for pat, tech, desc in _VER_FROM_JS:
                    if tech not in versions:
                        m = pat.search(inline_js)
                        if m:
                            versions[tech] = (m.group(1), f"inline JS ({desc})")

            # ── HTML comments (many libraries embed version here) ──────
            all_comments = "\n".join(
                str(c) for c in soup.find_all(
                    string=lambda t: isinstance(t, Comment))
            )
            if all_comments:
                for pat, tech, desc in _VER_FROM_JS:
                    if tech not in versions:
                        m = pat.search(all_comments)
                        if m:
                            versions[tech] = (m.group(1), f"HTML comment ({desc})")

            # ── Meta tags (most reliable for CMSes) ───────────────────
            for pat, tech in _VER_FROM_META:
                if tech not in versions:
                    m = pat.search(body)
                    if m:
                        versions[tech] = (m.group(1), "meta generator tag")

            # ── ng-version attribute (Angular) ────────────────────────
            ng_el = soup.find(attrs={"ng-version": True})
            if ng_el and "Angular" not in versions:
                versions["Angular"] = (ng_el["ng-version"], "ng-version HTML attribute")

        except Exception:
            pass

        return versions

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _merge(results: list[dict], name: str, match_type: str,
               conf: int, evidence: str) -> None:
        for r in results:
            if r["name"] == name:
                if conf > r["confidence"]:
                    r["confidence"] = conf
                    r["evidence"]   = evidence
                return
        sig = SIGS.get(name, {})
        results.append({"name": name, "category": sig.get("cat", "?"),
                        "version": None, "confidence": conf,
                        "match_type": match_type, "evidence": evidence})

    @staticmethod
    def _set_version(results: list[dict], name: str,
                     version: str, source_desc: str) -> None:
        """Set version on an existing result, or record where it came from."""
        for r in results:
            if r["name"] == name:
                if not r.get("version") and version:
                    r["version"]        = version
                    r["version_source"] = source_desc
                    r["evidence"]       = r.get("evidence", "") + f" | Version {version} from {source_desc}"
                return
