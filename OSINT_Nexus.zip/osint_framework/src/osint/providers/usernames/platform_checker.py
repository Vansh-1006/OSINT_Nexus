
"""Username Platform Checker — quality-first: GET requests, 20 concurrent, 10s timeout."""
from __future__ import annotations
import asyncio, time
from pathlib import Path
from typing import Optional
import httpx, yaml
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

_PF = Path(__file__).parent.parent.parent.parent.parent / "data" / "platforms.yaml"

class PlatformCheckerProvider(BaseProvider):
    name        = "username_platforms"
    description = "Username enumeration across 60+ platforms — GET, 20 concurrent"
    applies_to  = ["username"]
    _platforms: list[dict] = []

    def _load(self) -> list[dict]:
        if not self.__class__._platforms:
            self.__class__._platforms = yaml.safe_load(open(_PF)).get("platforms", [])
        return self.__class__._platforms

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "username":
            return self._skip("Username only")
        start     = time.monotonic()
        username  = target.normalized
        platforms = self._load()
        concurrent= self.config.get("concurrent", 20)
        sem       = asyncio.Semaphore(concurrent)
        reqs      = 0

        async def check(p: dict) -> Optional[Finding]:
            nonlocal reqs
            url = p["url"].replace("{username}", username)
            et  = p.get("error_type", "status_code")
            async with sem:
                try:
                    r = await self.client.get(url, timeout=self.timeout)
                    reqs += 1
                    if et == "status_code":
                        found = (r.status_code == 200)
                    elif et == "message":
                        em    = p.get("error_message", "")
                        found = (r.status_code == 200 and
                                 em.lower() not in r.text.lower())
                    elif et == "redirect":
                        found = str(r.url).rstrip("/") == url.rstrip("/")
                    else:
                        found = (r.status_code == 200)
                    if found:
                        return Finding(
                            source="username_platforms",
                            category=FindingCategory.PROFILE,
                            entity_type=EntityType.PROFILE,
                            value=f"{p['name']}: {username}",
                            url=str(r.url),
                            confidence=Confidence.HIGH,
                            evidence=(f"HTTP {r.status_code} — public profile on "
                                      f"{p['name']} [{p.get('category','?')}]"),
                            pivot_from=username,
                            metadata={"platform": p["name"],
                                      "category": p.get("category","?"),
                                      "profile_url": str(r.url)})
                except Exception:
                    pass
                return None

        results  = await asyncio.gather(*[check(p) for p in platforms], return_exceptions=True)
        findings = [r for r in results if isinstance(r, Finding)]
        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
