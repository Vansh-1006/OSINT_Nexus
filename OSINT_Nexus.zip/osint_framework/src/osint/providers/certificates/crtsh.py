
"""Certificate Transparency via crt.sh — limit 300 for maximum coverage."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class CrtShProvider(BaseProvider):
    name        = "crt_sh"
    description = "Certificate Transparency (crt.sh) — subdomains, org names, dates"
    applies_to  = ["domain", "email"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start  = time.monotonic()
        domain = target.normalized.split("@")[-1] if target.type.value == "email" else target.normalized
        findings: list[Finding] = []
        try:
            r = await self.client.get(
                f"https://crt.sh/?q=%.{domain}&output=json",
                timeout=self.timeout)
            if r.status_code != 200:
                return ProviderResult(provider=self.name, status=ProviderStatus.NO_RESULTS,
                                      duration=self._timed(start), requests_made=1)
            seen: set[str] = set()
            for entry in r.json():
                for name in entry.get("name_value", "").splitlines():
                    n = name.strip().lower().lstrip("*.")
                    if not n or n in seen:
                        continue
                    seen.add(n)
                    findings.append(Finding(
                        source="crt_sh", category=FindingCategory.CERTIFICATE,
                        entity_type=EntityType.DOMAIN, value=n,
                        url=f"https://crt.sh/?q={n}", confidence=Confidence.CONFIRMED,
                        evidence=(f"Certificate Transparency log | "
                                  f"Issuer: {entry.get('issuer_name','?')[:80]} | "
                                  f"Valid from: {entry.get('not_before','?')[:10]}"),
                        pivot_from=domain,
                        metadata={"issuer": entry.get("issuer_name"),
                                  "not_before": entry.get("not_before"),
                                  "not_after":  entry.get("not_after")}))
                    if len(findings) >= 300:  # increased from 150
                        break
                if len(findings) >= 300:
                    break
        except Exception:
            pass
        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=1)
