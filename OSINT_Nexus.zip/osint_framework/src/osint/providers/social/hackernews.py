
"""HackerNews — public profile, posts, comments via Algolia API."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class HackerNewsProvider(BaseProvider):
    name        = "hackernews"
    description = "Hacker News — profile, karma, posts via public Firebase + Algolia APIs"
    applies_to  = ["username"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "username":
            return self._skip("HN only for username targets")
        start    = time.monotonic()
        username = target.normalized
        findings : list[Finding] = []
        reqs     = 0

        # Firebase user endpoint
        try:
            r = await self.client.get(
                f"https://hacker-news.firebaseio.com/v0/user/{username}.json", timeout=8)
            reqs += 1
            if r.status_code == 200 and r.text and r.text != "null":
                data    = r.json()
                karma   = data.get("karma",0)
                about   = data.get("about","")
                created = data.get("created",0)
                import datetime
                created_str = datetime.datetime.utcfromtimestamp(created).strftime("%Y-%m-%d") if created else "?"
                import re
                about_clean = re.sub(r"<[^>]+>","", about).strip()[:300]
                findings.append(Finding(source="hackernews", category=FindingCategory.PROFILE,
                    entity_type=EntityType.PROFILE, value=f"HackerNews: {username}",
                    url=f"https://news.ycombinator.com/user?id={username}",
                    confidence=Confidence.CONFIRMED,
                    evidence=f"Account since: {created_str} | Karma: {karma:,} | About: {about_clean[:150]}",
                    pivot_from=username, metadata={"karma":karma,"created_utc":created,"about":about_clean}))

                # Extract URLs from about section
                for url in re.findall(r'https?://[^\s<>"]+', about):
                    findings.append(Finding(source="hackernews", category=FindingCategory.DOMAIN,
                        entity_type=EntityType.WEBSITE, value=url, url=url,
                        confidence=Confidence.HIGH,
                        evidence=f"URL in HackerNews profile bio of {username}",
                        pivot_from=username))
        except Exception:
            pass

        # Algolia for recent submissions
        try:
            r2 = await self.client.get(
                f"https://hn.algolia.com/api/v1/search?tags=author_{username},story&hitsPerPage=8",
                timeout=10)
            reqs += 1
            if r2.status_code == 200:
                for hit in r2.json().get("hits",[]):
                    title   = hit.get("title","")[:120]
                    hn_url  = f"https://news.ycombinator.com/item?id={hit.get('objectID','')}"
                    points  = hit.get("points",0)
                    if title:
                        findings.append(Finding(source="hackernews", category=FindingCategory.POST,
                            entity_type=EntityType.POST, value=title,
                            url=hn_url, confidence=Confidence.CONFIRMED,
                            evidence=f"HN post by {username}: '{title}' — {points} points",
                            pivot_from=username, metadata={"points":points}))
        except Exception:
            pass

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
