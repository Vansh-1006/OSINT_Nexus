
"""Reddit public API — profile, post history, comments, subreddits."""
from __future__ import annotations
import time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class RedditProvider(BaseProvider):
    name        = "reddit"
    description = "Reddit public API — profile, posts, comments, subreddit activity"
    applies_to  = ["username"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        if target.type.value != "username":
            return self._skip("Reddit only for username targets")
        start    = time.monotonic()
        username = target.normalized
        findings : list[Finding] = []
        reqs     = 0
        hdrs     = {"User-Agent": "osint-framework/2.0 (research tool)"}

        # Profile
        try:
            r = await self.client.get(
                f"https://www.reddit.com/user/{username}/about.json",
                headers=hdrs, timeout=10)
            reqs += 1
            if r.status_code == 200:
                data = r.json().get("data",{})
                karma_post    = data.get("link_karma", 0)
                karma_comment = data.get("comment_karma", 0)
                created       = data.get("created_utc", 0)
                verified      = data.get("verified", False)
                icon          = data.get("icon_img","")
                is_gold       = data.get("is_gold", False)
                import datetime
                created_str   = datetime.datetime.utcfromtimestamp(created).strftime("%Y-%m-%d") if created else "?"
                findings.append(Finding(source="reddit", category=FindingCategory.PROFILE,
                    entity_type=EntityType.PROFILE, value=f"Reddit: u/{username}",
                    url=f"https://www.reddit.com/user/{username}",
                    confidence=Confidence.CONFIRMED,
                    evidence=(f"Account created: {created_str} | "
                              f"Post karma: {karma_post:,} | Comment karma: {karma_comment:,} | "
                              f"Verified: {verified} | Premium: {is_gold}"),
                    pivot_from=username, metadata={"post_karma":karma_post,
                        "comment_karma":karma_comment,"created_utc":created,"verified":verified}))
                if icon:
                    findings.append(Finding(source="reddit", category=FindingCategory.IMAGE,
                        entity_type=EntityType.IMAGE, value=icon, url=icon,
                        confidence=Confidence.CONFIRMED, evidence=f"Reddit avatar for u/{username}",
                        pivot_from=username))
        except Exception:
            pass

        # Recent posts
        try:
            r2 = await self.client.get(
                f"https://www.reddit.com/user/{username}/submitted.json?limit=10",
                headers=hdrs, timeout=10)
            reqs += 1
            if r2.status_code == 200:
                for post in r2.json().get("data",{}).get("children",[]):
                    pd = post.get("data",{})
                    title    = pd.get("title","")[:120]
                    subreddit= pd.get("subreddit","")
                    score    = pd.get("score", 0)
                    post_url = f"https://www.reddit.com{pd.get('permalink','')}"
                    findings.append(Finding(source="reddit", category=FindingCategory.POST,
                        entity_type=EntityType.POST, value=f"[r/{subreddit}] {title}",
                        url=post_url, confidence=Confidence.CONFIRMED,
                        evidence=f"Public Reddit post by u/{username} in r/{subreddit} — Score: {score}",
                        pivot_from=username, metadata={"subreddit":subreddit,"score":score}))
        except Exception:
            pass

        # Recent comments (subreddit activity)
        try:
            r3 = await self.client.get(
                f"https://www.reddit.com/user/{username}/comments.json?limit=15",
                headers=hdrs, timeout=10)
            reqs += 1
            if r3.status_code == 200:
                subreddits: set[str] = set()
                for comment in r3.json().get("data",{}).get("children",[]):
                    cd  = comment.get("data",{})
                    sub = cd.get("subreddit","")
                    if sub: subreddits.add(sub)
                if subreddits:
                    findings.append(Finding(source="reddit", category=FindingCategory.PROFILE,
                        entity_type=EntityType.MENTION, value=f"Active in: r/{', r/'.join(sorted(subreddits)[:15])}",
                        url=f"https://www.reddit.com/user/{username}/comments/",
                        confidence=Confidence.CONFIRMED,
                        evidence=f"u/{username} has public comments in {len(subreddits)} subreddit(s)",
                        pivot_from=username, metadata={"subreddits":list(subreddits)}))
        except Exception:
            pass

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)
