
"""GitHub public REST API — profiles, repos, orgs, emails, gists."""
from __future__ import annotations
import time
from typing import Any, Optional
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class GitHubProvider(BaseProvider):
    name        = "github"
    description = "GitHub REST API — profile, repos, orgs, emails, gists"
    applies_to  = ["username","email"]

    def __init__(self, config):
        super().__init__(config)
        self._key = config.get("api_key","")

    @property
    def _hdrs(self):
        h = {"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28"}
        if self._key: h["Authorization"] = f"Bearer {self._key}"
        return h

    async def _get(self, path):
        try:
            r = await self.client.get(f"https://api.github.com{path}", headers=self._hdrs, timeout=self.timeout)
            return r.json() if r.status_code == 200 else None, r.status_code
        except Exception:
            return None, 0

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start = time.monotonic(); findings = []; reqs = 0
        if target.type.value == "username":
            f, r = await self._by_username(target.normalized)
            findings.extend(f); reqs += r
        elif target.type.value == "email":
            f, r = await self._by_email(target.normalized)
            findings.extend(f); reqs += r
        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)

    async def _by_username(self, username):
        findings = []
        user, code = await self._get(f"/users/{username}")
        reqs = 1
        if code == 403 or not user: return findings, reqs

        # Core profile
        findings.append(Finding(source="github", category=FindingCategory.DEVELOPER,
            entity_type=EntityType.PROFILE, value=f"GitHub: {user.get('login')}",
            url=user.get("html_url"), confidence=Confidence.CONFIRMED,
            evidence=f"GitHub profile — {user.get('public_repos',0)} public repos, {user.get('followers',0)} followers",
            pivot_from=username, metadata={k:user.get(k) for k in
                ["login","name","bio","company","location","blog","public_repos","followers","created_at","avatar_url"]}))

        if user.get("name"):
            findings.append(Finding(source="github", category=FindingCategory.PROFILE,
                entity_type=EntityType.PERSON, value=user["name"], url=user.get("html_url"),
                confidence=Confidence.HIGH, evidence=f"Real name on GitHub profile of {username}",
                pivot_from=username))
        if user.get("email"):
            findings.append(Finding(source="github", category=FindingCategory.EMAIL,
                entity_type=EntityType.EMAIL, value=user["email"], url=user.get("html_url"),
                confidence=Confidence.CONFIRMED, evidence=f"Public email on GitHub profile of {username}",
                pivot_from=username))
        if user.get("blog","").strip():
            blog = user["blog"].strip()
            if not blog.startswith("http"): blog = "https://" + blog
            findings.append(Finding(source="github", category=FindingCategory.DOMAIN,
                entity_type=EntityType.WEBSITE, value=user["blog"], url=blog,
                confidence=Confidence.HIGH, evidence=f"Website listed on GitHub profile of {username}",
                pivot_from=username))
        if user.get("company","").strip():
            findings.append(Finding(source="github", category=FindingCategory.ORGANIZATION,
                entity_type=EntityType.ORGANIZATION, value=user["company"].lstrip("@"),
                confidence=Confidence.MEDIUM, evidence=f"Organisation on GitHub profile of {username}",
                pivot_from=username))
        if user.get("avatar_url"):
            findings.append(Finding(source="github", category=FindingCategory.IMAGE,
                entity_type=EntityType.IMAGE, value=user["avatar_url"], url=user["avatar_url"],
                confidence=Confidence.CONFIRMED, evidence=f"GitHub avatar for {username}",
                pivot_from=username))

        # Repos
        repos, _ = await self._get(f"/users/{username}/repos?per_page=30&sort=updated")
        reqs += 1
        for repo in (repos or [])[:20]:
            if repo.get("fork"): continue
            findings.append(Finding(source="github", category=FindingCategory.REPOSITORY,
                entity_type=EntityType.REPOSITORY, value=repo.get("full_name",""),
                url=repo.get("html_url"), confidence=Confidence.CONFIRMED,
                evidence=(f"Public repo: ★{repo.get('stargazers_count',0)} | "
                          f"Language: {repo.get('language','?')} | "
                          f"Topics: {', '.join(repo.get('topics',[])[:5])}"),
                pivot_from=username, metadata={"stars":repo.get("stargazers_count"),
                    "language":repo.get("language"),"topics":repo.get("topics",[])}))
            if repo.get("homepage","").strip():
                findings.append(Finding(source="github", category=FindingCategory.DOMAIN,
                    entity_type=EntityType.WEBSITE, value=repo["homepage"],
                    url=repo["homepage"], confidence=Confidence.MEDIUM,
                    evidence=f"Homepage from repo {repo.get('full_name','')}",
                    pivot_from=username))

        # Orgs
        orgs, _ = await self._get(f"/users/{username}/orgs")
        reqs += 1
        for org in (orgs or []):
            findings.append(Finding(source="github", category=FindingCategory.ORGANIZATION,
                entity_type=EntityType.ORGANIZATION, value=org.get("login",""),
                url=f"https://github.com/{org.get('login','')}",
                confidence=Confidence.CONFIRMED,
                evidence=f"Public GitHub org membership for {username}",
                pivot_from=username))
        return findings, reqs

    async def _by_email(self, email):
        data, code = await self._get(f"/search/users?q={email}+in:email&per_page=5")
        if code == 403 or not data: return [], 1
        findings = []
        for item in data.get("items",[]):
            findings.append(Finding(source="github", category=FindingCategory.PROFILE,
                entity_type=EntityType.PROFILE, value=f"GitHub: {item.get('login')}",
                url=item.get("html_url"), confidence=Confidence.MEDIUM,
                evidence=f"GitHub user search matched for email {email}",
                pivot_from=email, metadata={"login":item.get("login")}))
        return findings, 1
