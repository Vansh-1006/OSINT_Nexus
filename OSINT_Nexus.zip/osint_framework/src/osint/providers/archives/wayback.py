
"""Wayback Machine — 4 URL patterns for usernames, fetched concurrently."""
from __future__ import annotations
import asyncio, time
import httpx
from osint.models import (Confidence, EntityType, Finding, FindingCategory,
                           InvestigationTarget, ProviderResult, ProviderStatus)
from osint.providers.base import BaseProvider

class WaybackProvider(BaseProvider):
    name        = "wayback_machine"
    description = "Wayback Machine CDX — historical snapshots, 4 patterns for usernames"
    applies_to  = ["domain", "username", "email"]

    async def investigate(self, target: InvestigationTarget) -> ProviderResult:
        start = time.monotonic(); findings = []; reqs = 0

        if target.type.value == "domain":
            f, r = await self._search(target.normalized, limit=25)
            findings.extend(f); reqs += r

        elif target.type.value == "username":
            u = target.normalized
            patterns = [
                (f"github.com/{u}",   8),
                (f"twitter.com/{u}",  5),
                (f"reddit.com/user/{u}", 5),
                (f"linkedin.com/in/{u}", 5),
            ]
            results = await asyncio.gather(
                *[self._search(p, limit=lim) for p, lim in patterns],
                return_exceptions=True)
            for res in results:
                if isinstance(res, tuple):
                    f, r = res; findings.extend(f); reqs += r

        elif target.type.value == "email":
            domain = target.normalized.split("@")[-1]
            f, r   = await self._search(domain, limit=15)
            findings.extend(f); reqs += r

        return ProviderResult(provider=self.name,
            status=ProviderStatus.SUCCESS if findings else ProviderStatus.NO_RESULTS,
            findings=findings, duration=self._timed(start), requests_made=reqs)

    async def _search(self, q: str, limit: int = 25) -> tuple[list, int]:
        findings = []
        params = {"url": f"*.{q}/*" if "." in q and "/" not in q else q,
                  "output": "json", "limit": limit,
                  "fl": "original,timestamp,statuscode,mimetype",
                  "filter": "statuscode:200", "collapse": "urlkey"}
        try:
            r = await self.client.get("https://web.archive.org/cdx/search/cdx",
                                      params=params, timeout=self.timeout)
            if r.status_code != 200: return findings, 1
            rows = r.json()
            if not rows or len(rows) < 2: return findings, 1
            for row in rows[1:]:
                if len(row) < 4: continue
                orig, ts, status, mime = row[0], row[1], row[2], row[3]
                yr, mo, dy = ts[:4], ts[4:6], ts[6:8]
                arch_url   = f"https://web.archive.org/web/{ts}/{orig}"
                findings.append(Finding(
                    source="wayback_machine", category=FindingCategory.ARCHIVE,
                    entity_type=EntityType.ARCHIVE,
                    value=f"[{yr}-{mo}-{dy}] {orig}", url=arch_url,
                    confidence=Confidence.CONFIRMED,
                    evidence=f"Archived {yr}-{mo}-{dy} | MIME: {mime}",
                    pivot_from=q,
                    metadata={"original_url": orig, "timestamp": ts, "archive_url": arch_url}))
        except Exception:
            pass
        return findings, 1
